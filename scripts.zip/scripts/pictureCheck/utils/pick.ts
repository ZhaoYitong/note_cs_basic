import glob from 'glob'
import path, { resolve } from 'path'
import { wrapLog } from '../../utils'

const projectRoot = path.resolve(__dirname, '../../../')

export const getAllImages = () => {
  const imgFiles: any[] = glob.sync('**/*.{png,jpg,jpeg,gif,svg}', {
    cwd: projectRoot, // 从源码目录扫描
    nodir: true, // 只获取文件不遍历目录
    ignore: ['node_modules/**', '**/dist/**']
  })
  wrapLog.yellow('Total image files: ' + imgFiles.length)
  const results: Record<string, string[]> = {}
  imgFiles.forEach(file => {
    const name = file.split('/').pop()
    if (name) {
      const fullPathFile = resolve(projectRoot, file)
      if (results[name]) {
        results[name].push(fullPathFile)
      } else {
        results[name] = [fullPathFile]
      }
    }
  })
  return results
}

export const getRepeatFiles = (files: Record<string, string[]>) => {
  const results: Record<string, string[]> = {}
  const keys = Object.keys(files).filter(it => files[it].length > 1)
  keys.forEach(key => {
    results[key] = files[key]
  })
  return results
}

// 由于 Icon 和 NewIcon组件会对指定的图片类型自动追加后缀如 _s,_n,_d，这里优先截图，方便ast字符串匹配
export const getSvgDefines = (files: Record<string, string[]>) => {
  const results: Record<string, string[]> = {}
  Object.keys(files).forEach(key => {
    const fileTypeRegex = /(\.svg)$/
    const fileTypeMatch = key.match(fileTypeRegex)
    if (fileTypeMatch) {
      const fileTypeSuffix = fileTypeMatch[0]
      const fileTypeNewKey = key.replace(fileTypeSuffix, '')
      results[fileTypeNewKey] = files[key]
      // 如果是Icon或NewIcon组件，去除后缀
      const regex = /\_[a-zA-Z](\.svg)$/
      const match = key.match(regex)
      // 匹配成功，去除匹配到的部分
      if (match) {
        const suffix = match[0]
        const newKey = key.replace(suffix, '')
        results[newKey] = files[key]
      }
    }
  })

  return results
}
