import { readdirSync } from 'fs'
import { resolve } from 'path'
import type { IOnFindKey, onFindKeyFnParam } from './parser/common'
import { findKeyByJsFn } from './parser/jsTsTsx'
import { findKeyByCssFn } from './parser/css'
import { findPictureKeyByLessFile } from './parser/less'

const dir = resolve(__dirname, '../../../')

const regMap = {
  less: /^(.)*(\.less)$/,
  css: /^(.)*(\.css)$/,
  js: /^((?!\.d\.ts)(?!\.min\.js).)*(\.ts|\.tsx|\.js)$/
}

const mainFolderReg = /apps|components|features|utils|src|pages/
const appSubFolderReg = /^((?!node_modules|dist\/|\.history|\.umi|locales).)*$/

const getFiles = (mainDir: string, fileType: 'css' | 'js' | 'less') => {
  const fileList: any[] = []
  const fileTypeRegex = regMap[fileType]
  const tranverseFiles = (dir: string, files: string[]) => {
    const entrys = readdirSync(dir, { withFileTypes: true })
    entrys.forEach(dirent => {
      const filePath = resolve(dir, dirent.name)
      if (mainFolderReg.test(filePath)) {
        if (appSubFolderReg.test(filePath)) {
          if (dirent.isDirectory()) {
            tranverseFiles(filePath, files)
          } else if (fileTypeRegex.test(filePath)) {
            files.push(filePath)
          }
        }
      }
    })
  }
  tranverseFiles(mainDir, fileList)

  return fileList
}

// [{"abc.svg": ["fileName:lineNumber"]}]
const picUsingContainer: Record<string, string[]> = {}
// {"abc.svg": "abc.svg"}
const endContainer: Record<string, string> = {}
// { "url('~@/assets/abc.svg')": "url('~@/assets/abc.svg')"}
const midContainer: Record<string, string> = {}

const onFindKey: IOnFindKey = ({
  endContainerKey,
  midContainerKey,
  colNumber,
  fileName,
  lineNumber
}: onFindKeyFnParam) => {
  let newUsingKey: string
  const keyLoc = `${fileName}:${lineNumber}:${colNumber}`
  if (midContainerKey) {
    newUsingKey = midContainerKey
    midContainer[midContainerKey] = midContainerKey
  } else {
    newUsingKey = endContainerKey
    endContainer[endContainerKey] = endContainerKey
  }
  if (picUsingContainer[newUsingKey]) {
    picUsingContainer[newUsingKey].push(keyLoc)
  } else {
    picUsingContainer[newUsingKey] = [keyLoc]
  }
}
// 检查
// 标记
// 生成引用关联位置
// 生成未使用的图片
export const checkPicFile = async (
  allPic: Record<string, string[]>,
  allSvgDefines: Record<string, string[]>
): Promise<{ picUsing: Record<string, string[]>; picUnused: Record<string, string[]>[] }> => {
  const lessFiles = getFiles(dir, 'less')
  const jsFiles = getFiles(dir, 'js')
  const cssFiles = getFiles(dir, 'css')
  console.log('less file numbers:', lessFiles.length)
  console.log('js,ts,tsx file numbers:', jsFiles.length)
  console.log('css file numbers:', cssFiles.length)

  await Promise.all([
    lessFiles.forEach(lFile => findPictureKeyByLessFile(lFile, onFindKey)),
    cssFiles.forEach(cFile => findKeyByCssFn(cFile, onFindKey)),
    jsFiles.forEach(jFile => findKeyByJsFn(jFile, allSvgDefines, onFindKey))
  ])
  const picUnused: Record<string, string[]>[] = []
  Object.keys(allPic).forEach(key => {
    if (!endContainer[key] && !Object.keys(midContainer).find(k => k.includes(key))) {
      picUnused.push({
        [key]: allPic[key]
      })
    }
  })
  return {
    picUsing: picUsingContainer,
    picUnused: picUnused
  }
}
