import fs from 'fs'
import readline from 'readline'
import glob from 'glob'
import path from 'path'
import { wrapLog } from '../../utils'

const projectRoot = path.resolve(__dirname, '../../../')

export const getPictureToCleanSearch = (picUnused: Record<string, string[]>[]) => {
  const possibleKeysToClean = picUnused.filter(p => {
    const pKey = Object.keys(p)[0]
    // 这部分后缀在代码中可能会以其他形式出现
    return (
      !pKey.endsWith('_d.svg') &&
      !pKey.endsWith('_s.svg') &&
      !pKey.endsWith('_n.svg') &&
      !pKey.endsWith('_en.svg')
    )
  })

  const keyMap: Record<string, string[]> = {}
  const pictureToCleanMap: Record<string, string[]> = {}
  const searchKeyDict: Record<string, string> = {}
  possibleKeysToClean.forEach(p => {
    const pKey = Object.keys(p)[0]
    const searchKey = pKey.replace(/.svg|.png|.jpg|.jpeg/g, '')
    searchKeyDict[searchKey] = pKey
    keyMap[searchKey] = p[pKey]
  })

  const files = glob.sync('**/*.{js,ts,jsx,tsx,json}', {
    cwd: projectRoot, // 从源码目录扫描
    ignore: ['node_modules/**', '**/dist/**', '.umi/', '**/log/**']
  })
  Object.keys(keyMap).forEach(key => {
    const searchPatterns = new RegExp(`(${key})`)
    let isFind = false

    for (let i = 0; i < files.length; i++) {
      const fileContent = fs.readFileSync(files[i], 'utf8')
      if (searchPatterns.test(fileContent)) {
        isFind = true
        break
      }
    }
    if (!isFind) {
      if (!pictureToCleanMap[key]) {
        pictureToCleanMap[key] = keyMap[key]
      } else {
        pictureToCleanMap[key] = pictureToCleanMap[key].concat(keyMap[key])
      }
    }
  })

  return pictureToCleanMap
}

export const autoCleanPictureWithConfirm = (
  picToClean: Record<string, string[]>,
  logPath: string
) => {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  })

  wrapLog.red('Total picture to clean: ' + Object.keys(picToClean).length)
  rl.question(`Are you sure to delete pictures in ${logPath} ? (yes/no)`, answer => {
    if (answer.toLocaleLowerCase() === 'yes') {
      Object.keys(picToClean).forEach(key => {
        const files: string[] = picToClean[key]
        files.forEach(file => {
          fs.unlinkSync(file)
        })
      })
    }
    rl.close()
  })
}
