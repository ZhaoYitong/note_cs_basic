import postcss from 'postcss'
import syntaxParser from 'postcss-less'
import { readFileSync } from 'fs'
import { endwithPicType, includePicTypeCheck } from './common'
import type { IOnFindKey } from './common'

export const findPictureKeyByLessFile = async (fileName: string, onFind: IOnFindKey) => {
  const code = readFileSync(fileName, { encoding: 'utf-8' })
  postcss()
    .process(code, { syntax: syntaxParser as any, from: fileName })
    .then(result => {
      result.root.walkDecls(decl => {
        const propertyValue = decl.value
        // @ts-ignore
        const start: any = decl.source.start
        if (includePicTypeCheck(propertyValue)) {
          const picFileName = propertyValue.split('/').pop() || ''
          if (endwithPicType(picFileName)) {
            onFind({
              fileName,
              lineNumber: start.line,
              colNumber: start.column || 0,
              endContainerKey: picFileName
            })
          } else {
            onFind({
              fileName,
              lineNumber: start.line,
              endContainerKey: picFileName,
              colNumber: start.column || 0,
              midContainerKey: propertyValue
            })
          }
        }
      })
    })
    .catch(error => {
      console.error(error)
    })
}
