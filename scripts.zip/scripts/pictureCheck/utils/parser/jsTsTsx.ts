import { readFileSync } from 'fs'
import { parse } from '@babel/parser'
import traverse from '@babel/traverse'
import type { IFindKeyParam, IOnFindKey } from './common'
import { includePicTypeCheck } from './common'

/**
 * FIXME:
 *  1. 目前CMP的图片使用组件未完全统一：如img标签，Icon组件，NewIcon组件，src属性等等。
 *  2. UI设计提供的icon名称最好以统一前缀开头，如：icon-xxx，icon-xxx-xxx，方便标识区分。
 *  3. 存在一些特殊情况暂未兼容，如：html标签行内样式，字符串拼接等等，可能会有遗漏场景，后续需要完善。
 *  4. 这里相当于取巧，默认AST树节点值即字符串类型，不可再分。
 * @param params
 * @returns
 */
const findKeyFn = (params: IFindKeyParam) => {
  const { ast, fileName, allSvgDefines, onFind } = params
  const result: any = {
    unparsed: [],
    identifier: [],
    memberExpression: [],
    unstandard: [],
    parseError: []
  }
  traverse(ast, {
    enter(nodePath) {
      // 字符串以图片格式结尾
      if (nodePath.node.type === 'StringLiteral') {
        const stringValue = nodePath.node.value
        if (includePicTypeCheck(stringValue)) {
          const fileName = stringValue.split('/').pop() || ''
          onFind({
            fileName,
            lineNumber: nodePath.node.loc?.start.line || 0,
            colNumber: nodePath.node.loc?.start.column || 0,
            endContainerKey: fileName
          })
        } else if (allSvgDefines[stringValue]?.length > 0) {
          // <Icon type="abc" />
          // const iconType = 'abc'
          // TODO: 需要图标完善，统一前缀标识，减少误判
          onFind({
            fileName,
            lineNumber: nodePath.node.loc?.start.line || 0,
            colNumber: nodePath.node.loc?.start.column || 0,
            endContainerKey: `${stringValue}.svg`
          })
        }
      }
    }
  })
  return result
}

export const findKeyByJsFn = (
  fileName: string,
  allSvgDefines: Record<string, string[]>,
  onFind: IOnFindKey
) => {
  const code = readFileSync(fileName, { encoding: 'utf-8' })
  const ast = parse(code, {
    sourceType: 'module',
    plugins: ['typescript', 'jsx', 'classProperties', 'decorators-legacy']
  })
  const findResults = findKeyFn({ ast, fileName, allSvgDefines, onFind })
  return { ast, code, ...findResults }
}
