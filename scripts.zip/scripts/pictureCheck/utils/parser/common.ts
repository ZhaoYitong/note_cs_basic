import type * as t from '@babel/types'

export interface onFindKeyFnParam {
  fileName: string
  lineNumber: number
  colNumber: number
  endContainerKey: string
  midContainerKey?: string
}

export type IOnFindKey = (params: onFindKeyFnParam) => void

export interface IFindKeyParam {
  ast: t.File
  fileName: string
  allSvgDefines: Record<string, string[]>
  onFind: IOnFindKey
}

export const includePicTypeCheck = (propertyValue: string) => {
  if (
    propertyValue.includes('.svg') ||
    propertyValue.includes('.png') ||
    propertyValue.includes('.jpg')
  ) {
    return true
  }
  return false
}

export const endwithPicType = (propertyValue: string) => {
  if (
    propertyValue.endsWith('.svg') ||
    propertyValue.endsWith('.png') ||
    propertyValue.endsWith('.jpg')
  ) {
    return true
  }
  return false
}
