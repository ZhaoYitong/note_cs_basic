## 静态图片使用检查

### 目的
- 方便UI设计定期清理图片资源
- 降低项目体积
- 提高图片利用率

### 原理

#### 前提
- 所有在js/ts/tsx/jsx文件里引用的图片，在不指定文件类型时，一定是svg
- 重名的图片文件仅路径不一样，但属于一种图片（统一来自蓝湖UI设计稿）

#### 脚本扫描
- AST扫描项目中的全量代码 js, jsx, ts, tsx, json, css, less
  - 分类型扫描
    - js, jsx, ts, tsx
    - css
    - less
- 常用图片组件 Icon, NewIcon, img, CmpImage(统一用字符串类型判断)
  - Icon type
  - NewIcon type
  - img src
- 字符串常量 string
  - 项目中的所有字符串常量

### 输出
- 未使用的图片
- 多处重复使用的图片
- 重复的图片

