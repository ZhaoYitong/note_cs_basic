import { resolve } from 'path'
import { writeFile } from 'fs'
import mkdirp from 'mkdirp'
import { getFileNamePrefixWithGit, wrapLog, emptyDir } from '../utils'
import { checkPicFile } from './utils/check'
import { getAllImages, getRepeatFiles, getSvgDefines } from './utils/pick'
import { getPictureToCleanSearch, autoCleanPictureWithConfirm } from './utils/cleaner'

const allPics = getAllImages()
const repeating = getRepeatFiles(allPics)
const svgDefines = getSvgDefines(allPics)

checkPicFile(allPics, svgDefines).then(({ picUnused, picUsing }) => {
  emptyDir(resolve(__dirname, 'log'))
  mkdirp(resolve(__dirname, 'log'))

  const unStandardPicFiles: Record<string, string[]> = {}
  // UI库中统一两种图片前缀 icon_ 和 illustration_，其他的都是不规范的，待设计统一
  Object.keys(allPics)
    .filter(k => !k.startsWith('icon_') && !k.startsWith('illustration_'))
    .forEach(i => {
      if (!unStandardPicFiles[i]) {
        unStandardPicFiles[i] = allPics[i]
      }
    })

  const picToClean = getPictureToCleanSearch(picUnused)
  wrapLog.yellow('Total uniq picture number: ' + Object.keys(allPics).length)
  wrapLog.yellow('Total possible picture defines: ' + Object.keys(svgDefines).length)
  wrapLog.yellow('Total possible unused picture number: ' + picUnused.length)
  wrapLog.yellow('Total unstandard pictureName number: ' + Object.keys(unStandardPicFiles).length)
  console.log('-----------------------------------------------------------')
  const fileNamePrefix = getFileNamePrefixWithGit()
  const picToCleanLogPath = resolve(__dirname, `log/picToClean${fileNamePrefix}.log`)
  writeFile(picToCleanLogPath, JSON.stringify(picToClean, null, 2), 'utf-8', () => {})
  writeFile(
    resolve(__dirname, `log/unstandard${fileNamePrefix}.log`),
    JSON.stringify(unStandardPicFiles, null, 2),
    'utf-8',
    () => {}
  )
  writeFile(
    resolve(__dirname, `log/picUnused${fileNamePrefix}.log`),
    JSON.stringify(picUnused, null, 2),
    'utf-8',
    () => {}
  )

  writeFile(
    resolve(__dirname, `log/picUsing${fileNamePrefix}.log`),
    JSON.stringify(picUsing, null, 2),
    'utf-8',
    () => {}
  )

  writeFile(
    resolve(__dirname, `log/uniqImages${fileNamePrefix}.log`),
    JSON.stringify(allPics, null, 2),
    'utf-8',
    () => {}
  )

  writeFile(
    resolve(__dirname, `log/picRepeating${fileNamePrefix}.log`),
    JSON.stringify(repeating, null, 2),
    'utf-8',
    () => {}
  )

  writeFile(
    resolve(__dirname, `log/possibleSvgDefine${fileNamePrefix}.log`),
    JSON.stringify(svgDefines, null, 2),
    'utf-8',
    () => {}
  )

  autoCleanPictureWithConfirm(picToClean, picToCleanLogPath)
})
