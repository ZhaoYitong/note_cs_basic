export const MASTER_APP_PATH = 'apps/base'

// 由于后端是微服务架构，为保证配置拉取一致，这里写死了默认的开发环境IP
export const DEFAULT_DEV_IP = '172.20.12.62'

// 国际化node服务的管理节点IP
export const DEV_I18N_MGT_NODE_IP = '172.20.15.213'
