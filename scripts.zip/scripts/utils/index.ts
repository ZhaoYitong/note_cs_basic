import { readdirSync, unlinkSync, statSync, rmSync } from 'fs'
import cp, { execSync } from 'child_process'
import { Base64 } from 'js-base64'
import readline from 'readline'
import { join } from 'path'
import { Service } from 'umi'
import moment from 'moment'
import type { NodePath } from '@babel/traverse'
import type * as t from '@babel/types'
import { resolve } from 'path'
import chalk from 'chalk'
import { promisify } from 'util'
import { DEFAULT_DEV_IP, MASTER_APP_PATH } from './config'

const exec = promisify(cp.exec)

const { log } = console

export const wrapLog = {
  grey: (msg: string) => log(chalk.hex('#e8e8e8')(msg)),
  green: (msg: string) => log(chalk.hex('#73d13d')(msg)),
  yellow: (msg: string) => log(chalk.hex('#fff566')(msg)),
  red: (msg: string) => log(chalk.hex('#ff7875')(msg))
}

async function getCurrentGitBranch() {
  // git v1.8 没有 git branch --show-current
  const { stderr, stdout } = await exec(`git branch | grep '*' | awk -F' ' '{print $2}'`, {
    encoding: 'utf-8'
  })
  if (stderr) {
    wrapLog.red(stderr)
    return
  }
  wrapLog.green(`[Current Branch]: ${stdout.trim()}`)
  return stdout.trim()
}

export async function getCurrentRemoteBranch() {
  try {
    const currentBranch = await getCurrentGitBranch()
    if (!currentBranch) {
      return
    }
    const { stderr, stdout } = await exec(
      `git rev-parse --abbrev-ref --symbolic-full-name ${currentBranch}@{u}`,
      {
        encoding: 'utf-8'
      }
    )
    if (stderr) {
      wrapLog.red(stderr)
      return
    }
    const remoteBranch = stdout.trim()
    wrapLog.green(`[Remote Branch]: ${remoteBranch}`)
    return remoteBranch.replace('origin/', '')
  } catch (error: any) {
    wrapLog.red(error.message)
  }
}

export const getFileNamePrefixWithGit = () => {
  let namePrefix = ''
  try {
    // 执行 git rev-parse 命令来获取本地分支所映射的远程分支名
    const remoteBranch = execSync('git rev-parse --abbrev-ref --symbolic-full-name @{u}')
      .toString()
      .trim()
    const execDate = moment().format('YYYY-MM-DD-HH-mm-ss')
    wrapLog.yellow(`Local Remote Branch: ${remoteBranch}`)
    // origin/master -> origin-master
    namePrefix = `_${remoteBranch.split('/').join('_')}_${execDate}`
  } catch (error) {
    console.error(`Exec git error: ${error}`)
  }
  return namePrefix
}

export const getNodeLoc = (fileName: string, nodePath: NodePath<t.Node>) => {
  return `${fileName}:${nodePath.node.loc?.start.line}:${nodePath.node.loc?.start.column}`
}

// mock login
export const getCookieByLogin = async (
  devIp: string,
  username: string = 'admin',
  password: string = 'password'
) => {
  const url = `http://${devIp}:8100/portal/v4/pub/login`
  const res: any = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      method: 'local',
      username,
      password: Base64.encode(password)
    })
  }).then(res => res.json())
  return {
    token: res.data.token.token
  }
}

export const getDevIp = () => {
  // TODO: 可能需要后端支持，增加分支标识，git commitId hash 标识，git 最后一次提交记录标识...
  const newService = new Service({
    // TODO: 这里主应用的路径是写死的，需要解耦，可以尝试用umi的内置方法，直接获取主应用下的DEVIP
    // https://github.com/umijs/umi/blob/3.x/packages/core/src/Config/Config.ts#L40
    cwd: join(process.cwd(), MASTER_APP_PATH)
  })
  // https://github.com/umijs/umi/blob/3.x/packages/core/src/Service/Service.ts#L180
  newService.loadEnv()

  const devIp = process.env.DEVIP || ''
  return devIp
}

export const emptyDir = (path: string) => {
  try {
    const curfiles = readdirSync(path)
    curfiles.forEach(file => {
      const filePath = `${path}/${file}`
      const stats = statSync(filePath)
      if (stats.isDirectory()) {
        emptyDir(filePath)
      } else {
        unlinkSync(filePath)
        console.log(`Remove ${file} success!`)
      }
    })
    rmSync(resolve(__dirname, 'log'), { recursive: true })
  } catch {}
}

export const validateDefaultDevIp = (devIp: string, callback: Function): void => {
  if (devIp !== DEFAULT_DEV_IP) {
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout
    })
    rl.question(
      `当前配置获取环境 ${devIp} 不是默认环境 ${DEFAULT_DEV_IP}, 执行拉取命令后可能会导致权限数据不一致，确定要执行吗 ? (yes/no)`,
      answer => {
        if (answer.toLocaleLowerCase() === 'yes') {
          callback()
        }
        rl.close()
      }
    )
  } else {
    callback()
  }
}
