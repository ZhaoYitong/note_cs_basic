# apiCheck

`基于apiscan 和 apiget，输出api使用遗漏和定义遗漏，方便在测试前减少接口404问题，同时利于历史旧代码的删减，增强代码健壮性`

## 原理

### apiscan

`基于AST扫描request方法，输出 log/apiscan`

### apiget

`由后端接口支持，获取该服务下的所有api，输出 log/apiget`

### 聚合分析

`输出 log/analyze`

- apiget (api请求获取后端定义的全量api)
  - 预处理
    - {moId}, {id} ... 统一处理 => VARIABLE
    - 过滤 api 打头
    - 过滤 通配符 **

- apiscan (扫描当前cmp-ui的所有request方法下的api)
  - 预处理 
    - `${uuid} ${payload.id} 统一处理 => VARIABLE`

- 汇总分析 + 归并生成
  - 后端定义但前端未使用
  - 前端使用但后端未定义


## TODO

- log/analyze 中问题api整理与删减（+++）

- 完善聚合分析的边缘场景适配，补充相关log记录（+++）

- 基于apiget自动生成service层，不再手动维护api(+)
  - 需要后端进一步完善请求参数和请求体的注解



