import { readFileSync } from 'fs'
import { parse } from '@babel/parser'
import type { NodePath } from '@babel/traverse'
import traverse from '@babel/traverse' // acore
import type * as t from '@babel/types'
import { getNodeLoc } from '../utils'

interface onFindRequestFnParam {
  api: string
  nodePath: NodePath<t.Node>
  fileName: string
}
export type IOnFindRequest = (params: onFindRequestFnParam) => void

export interface IFindI18nParam {
  ast: t.File
  fileName: string
  onFindRequestFn?: IOnFindRequest
}

export interface IFindResult {
  identifier: string[]
  unparsed: string[]
  memberExpression: string[]
  unstandard: string[]
  parseError: string[]
}

const getMemberExpressionRawVal = (n: t.MemberExpression): string => {
  // @ts-ignore
  const memberExpRawArr = [n.property.name]
  const tranverseMemberTree = (node: t.MemberExpression, arr: string[]) => {
    if (node.object.type === 'Identifier') {
      arr.unshift(node.object.name)
    } else if (node.object.type === 'MemberExpression') {
      tranverseMemberTree(node.object, arr)
    }
  }
  tranverseMemberTree(n, memberExpRawArr)

  return memberExpRawArr.join('.')
}

// TODO: 需要提升节点获取数值的健壮性，最好直接调用底层支持的api
const getNodeValue = (nodePath: any, fileName: string, results: IFindResult) => {
  const firstArg = nodePath.node.arguments[0] as
    | t.StringLiteral
    | t.Identifier
    | t.TemplateLiteral
    | t.MemberExpression
  const currentFnLoc = getNodeLoc(fileName, nodePath)
  // 纯字符串 | 变量标识符 | 模板字符串
  if (firstArg.type === 'StringLiteral') {
    // query参数不应该出现在api上
    if (firstArg.value.includes('?')) {
      results.unstandard.push(currentFnLoc)
    } else {
      return firstArg.value
    }
  } else if (firstArg.type === 'TemplateLiteral') {
    // https://exploringjs.com/impatient-js/ch_template-literals.html#template-strings-cooked-vs-raw
    const quasisVals: any[] = firstArg.quasis.map(it => it.value.raw)
    const expressionVals: any[] = firstArg.expressions.map(it => {
      let expresionName = ''
      if (it.type === 'Identifier') {
        // ${uuid}
        expresionName = it.name
      } else if (it.type === 'MemberExpression') {
        // ${body.uuid}
        expresionName = getMemberExpressionRawVal(it)
      } else if (it.type === 'ConditionalExpression') {
        // ${body.uuid ? true : false}
        // TODO: goto unstandard
      } else if (it.type === 'CallExpression') {
      }
      if (expresionName) {
        return '${' + expresionName + '}'
      } else {
        results.unstandard.push(currentFnLoc)
        return ''
      }
    })
    const result: any[] = []
    let index_e = 0
    quasisVals.forEach((it, index_q) => {
      result.push(it)
      if (index_q < quasisVals.length - 1) {
        result.push(expressionVals[index_e])
        index_e++
      }
    })
    return result.join('')
  } else if (firstArg.type === 'Identifier') {
    results.identifier.push(currentFnLoc)
    return firstArg.name
  } else if (firstArg.type === 'MemberExpression') {
    const memberStr = getMemberExpressionRawVal(firstArg)
    results.memberExpression.push(currentFnLoc)
    return memberStr
  } else {
    results.unstandard.push(currentFnLoc)
  }
}

// request\(|request<
const findRequestFn = (params: IFindI18nParam) => {
  const { ast, fileName, onFindRequestFn } = params
  const result: IFindResult = {
    unparsed: [],
    identifier: [],
    memberExpression: [],
    unstandard: [],
    parseError: []
  }
  traverse(ast, {
    enter(nodePath) {
      // @ts-ignore
      if (nodePath.isCallExpression() && nodePath.node.callee.name === 'request') {
        const apiValue = getNodeValue(nodePath, fileName, result) || ''
        const currentFnLoc = getNodeLoc(fileName, nodePath)
        if (!apiValue) {
          result.unparsed.push(currentFnLoc)
        }
        try {
          if (onFindRequestFn) {
            onFindRequestFn({
              api: apiValue,
              fileName,
              nodePath
            })
          }
        } catch (e) {
          result.parseError.push(`something wrong in ${fileName}${e}`)
        }
      }
    }
  })
  return result
}

export const findRequestFnByFile = (fileName: string, onFindRequestFn: IOnFindRequest) => {
  const code = readFileSync(fileName, { encoding: 'utf-8' })
  const ast = parse(code, {
    sourceType: 'module',
    plugins: ['typescript', 'jsx', 'classProperties', 'decorators-legacy']
  })
  const findResults = findRequestFn({ ast, fileName, onFindRequestFn })
  return { ast, code, ...findResults }
}
