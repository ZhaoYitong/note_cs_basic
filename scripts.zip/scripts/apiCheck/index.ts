import { writeFile } from 'fs'
import { resolve } from 'path'
import mkdirp from 'mkdirp'
import { emptyDir, getFileNamePrefixWithGit, wrapLog } from '../utils'
import type { FApiGet } from './apiget'
import { runApiGet } from './apiget'
import type { FApi } from './apiscan'
import { runApiScan } from './apiscan'
type ApiGetResult = {
  api: string
  method: string
}[]
const analyzeApiResults = (
  apiScanList: FApi[],
  apiGetList: FApiGet[]
): {
  uiUnuse: ApiGetResult
  serverUnDefine: FApi[]
} => {
  const scanMap: Record<string, string> = {}
  const apiGetMap: Record<string, string> = {}
  apiScanList.forEach(i => {
    if (!scanMap[i.formatted]) {
      scanMap[i.formatted] = i.formatted
    }
  })
  apiGetList.forEach(i => {
    if (!apiGetMap[i.apiFormat]) {
      apiGetMap[i.apiFormat] = i.apiFormat
    }
  })
  // 后端定义但前端未使用
  const uiUnuse: ApiGetResult = []
  // 前端使用但后端未定义
  const serverUnDefine: FApi[] = []
  apiScanList.forEach(a => {
    if (!apiGetMap[a.formatted]) {
      serverUnDefine.push(a)
    }
  })
  apiGetList.forEach(a => {
    if (!scanMap[a.apiFormat]) {
      uiUnuse.push({
        api: a.apiOrigin,
        method: a.method
      })
    }
  })
  return {
    uiUnuse,
    serverUnDefine
  }
}

const main = () => {
  const fileNamePrefix = getFileNamePrefixWithGit()
  emptyDir(resolve(__dirname, 'log/analyze'))
  mkdirp(resolve(__dirname, 'log/analyze'))
  const apiScanList = runApiScan(fileNamePrefix)

  runApiGet(fileNamePrefix).then(apiGetResult => {
    const { uiUnuse, serverUnDefine } = analyzeApiResults(apiScanList, apiGetResult)
    wrapLog.red(`Defined by server but ui not using: ${uiUnuse.length} // 后端定义但前端未使用`)
    wrapLog.red(
      `Used by ui but server not define: ${serverUnDefine.length} // 前端使用但后端未定义`
    )

    const serverUndefineGrouped: Record<string, FApi[]> = {}
    serverUnDefine.forEach(i => {
      const app = i.api.split('/')[0]
      if (!serverUndefineGrouped[app]) {
        serverUndefineGrouped[app] = [i]
      } else {
        serverUndefineGrouped[app].push(i)
      }
    })
    writeFile(
      resolve(__dirname, `log/analyze/uiUnuse${fileNamePrefix}.log`),
      JSON.stringify(uiUnuse, null, 2),
      {
        encoding: 'utf-8'
      },
      () => {}
    )
    writeFile(
      resolve(__dirname, `log/analyze/serverUnDefine${fileNamePrefix}.log`),
      JSON.stringify(serverUndefineGrouped, null, 2),
      {
        encoding: 'utf-8'
      },
      () => {}
    )
  })
}

main()
