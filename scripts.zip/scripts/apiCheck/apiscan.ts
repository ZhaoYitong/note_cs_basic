import { readdirSync, writeFile } from 'fs'
import { resolve, relative } from 'path'
import mkdirp from 'mkdirp'
import type { IOnFindRequest } from './core'
import { findRequestFnByFile } from './core'
import { emptyDir } from '../utils'

export type Api = { api: string; relativePath: string; absolutePath: string }
export type FApi = Api & { formatted: string }
const rootDir = resolve(__dirname, '../../')
const files: string[] = []
const apiDefines: Record<string, string> = {}
const apiList: Api[] = []
let formatted: FApi[] = []
const wholeRequestFnList: [Api?] = []

const log: {
  identifier: string[]
  unparsed: string[]
  memberExpression: string[]
  unstandard: string[]
  parseError: string[]
} = {
  identifier: [],
  unparsed: [],
  memberExpression: [],
  unstandard: [],
  parseError: []
}

// 递归遍历文件夹并过滤
const getFiles = (dir: string) => {
  const entrys = readdirSync(dir, { withFileTypes: true })
  entrys.forEach(dirent => {
    const filePath = resolve(dir, dirent.name)
    if (/apps|components|features|utils|src|pages/.test(filePath)) {
      if (/^((?!node_modules|dist\/|\.history|\.umi|locales).)*$/.test(filePath)) {
        if (dirent.isDirectory()) {
          getFiles(filePath)
        } else if (/^((?!\.d\.ts)(?!\.md)(?!\.min\.js).)*(\.ts|\.tsx|\.js)$/.test(filePath)) {
          files.push(filePath)
        }
      }
    }
  })
}

const onFindRequestFn: IOnFindRequest = params => {
  const { api, fileName, nodePath } = params
  const relativePath = `${relative(rootDir, fileName)}:${nodePath.node.loc?.start.line}`
  const absolutePath = `${fileName}:${nodePath.node.loc?.start.line}:${nodePath.node.loc?.start.column}`
  wholeRequestFnList.push({
    api,
    relativePath,
    absolutePath
  })
  // TODO: 异常检测
  //    重复api
  //    变量
  if (apiDefines[api] && apiDefines[api] !== api) {
  } else {
    apiDefines[api] = api || ''
    if (!apiList.find((item: any) => item?.api === api)) {
      // // 带${}的api
      // if (/\${[^}]+}/.test(api)) {}
      apiList.push({
        api,
        relativePath,
        absolutePath
      })
    }
  }
}

const build = async (dir: string, fileNamePrefix: string) => {
  getFiles(dir)
  // writeFile(
  //   resolve(__dirname, `log/apiscan/files${fileNamePrefix}.log`),
  //   JSON.stringify(files, null, 2),
  //   {
  //     encoding: 'utf-8'
  //   },
  //   () => {}
  // )
  files.forEach(file => {
    try {
      const {
        unstandard = [],
        memberExpression = [],
        parseError = [],
        unparsed = [],
        identifier = []
      } = findRequestFnByFile(file, onFindRequestFn)
      log.parseError.push(...parseError)
      log.unstandard.push(...unstandard)
      log.identifier.push(...identifier)
      log.unparsed.push(...unparsed)
      log.memberExpression.push(...memberExpression)
    } catch (e) {
      console.error(file, e)
    }
  })

  formatted = apiList.map(item => {
    return {
      api: item?.api,
      formatted: item?.api?.split('?')[0]?.replace(/\${[^}]+}/g, 'VARIABLE'),
      relativePath: item?.relativePath,
      absolutePath: item?.absolutePath
    }
  })
  const noV4 = formatted.filter(i => !i.api.includes('/v4/'))
  const unStandardV4 = formatted.filter(i => {
    const tApi = i.api
    return tApi.split('/')[1] !== 'v4' && tApi.includes('/v4/')
  })
  console.log('v4Need:', noV4.length)
  console.log('unstandardV4:', unStandardV4.length)
  writeFile(
    resolve(__dirname, `log/apiscan/unstandard_v4${fileNamePrefix}.log`),
    JSON.stringify(unStandardV4, null, 2),
    'utf-8',
    () => {}
  )
  writeFile(
    resolve(__dirname, `log/apiscan/noV4${fileNamePrefix}.log`),
    JSON.stringify(noV4, null, 2),
    'utf-8',
    () => {}
  )
  writeFile(
    resolve(__dirname, `log/apiscan/apiList${fileNamePrefix}.log`),
    JSON.stringify(formatted, null, 2),
    'utf-8',
    () => {}
  )
  writeFile(
    resolve(__dirname, `log/apiscan/requestList${fileNamePrefix}.log`),
    JSON.stringify(wholeRequestFnList, null, 2),
    'utf-8',
    () => {}
  )
  writeFile(
    resolve(__dirname, `log/apiscan/error${fileNamePrefix}.log`),
    JSON.stringify(log, null, 2),
    'utf-8',
    () => {}
  )
  console.log('Total api:', apiList.length)
  console.log('Total requestFn:', wholeRequestFnList.length)
}

export const runApiScan = (fileNamePrefix: string): FApi[] => {
  emptyDir(resolve(__dirname, 'log/apiscan'))
  mkdirp(resolve(__dirname, 'log/apiscan'))
  build(rootDir, fileNamePrefix)
  return formatted
}
