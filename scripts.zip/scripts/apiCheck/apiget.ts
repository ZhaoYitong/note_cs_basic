import { writeFile } from 'fs'
import { resolve } from 'path'
import mkdirp from 'mkdirp'
import { emptyDir, getDevIp, wrapLog } from '../utils'

type ApiGetResult = Record<string, string>

export type FApiGet = {
  apiFormat: string
  apiOrigin: string
  method: string
}

const defaultServerApps = [
  'base',
  'connector',
  'maintenance',
  'operation',
  'oss',
  'portal',
  'rds',
  'ticket',
  'vm'
]

const apiWhiteList: string[] = ['v4/cloud-account/menu/init', '/debug', 'v4/pub/bigboard', 'priv/']
const fetchServerApiDefine = async (devIp: string, fileNamePrefix: string) => {
  const results: ApiGetResult = {}
  const serverTodo: ApiGetResult = {}
  wrapLog.yellow('Current server IP: ' + devIp)
  const rqList = defaultServerApps.map(appName =>
    fetch(`http://${devIp}:8100/${appName}/v4/pub/cmp-global/debug/listRoute`, {
      method: 'GET'
    }).then(res => res.json())
  )
  await Promise.all(rqList).then(rqRes => {
    rqRes.forEach((rqItem, index) => {
      if (rqItem.status) {
        console.log(
          `http://${devIp}:8100/${defaultServerApps[index]}/v4/pub/cmp-global/debug/listRoute failed`
        )
      } else {
        Object.keys(rqItem).forEach(i => {
          if (i.includes('/v4/') && !apiWhiteList.some(aItem => i.includes(aItem))) {
            const newApi = defaultServerApps[index] + i
            results[newApi] = rqItem[i].method
          } else {
            serverTodo[i] = i
          }
        })
      }
    })
  })
  writeFile(
    resolve(__dirname, `log/apiget/apiTodo_${fileNamePrefix}.json`),
    JSON.stringify(serverTodo, null, 2),
    {
      encoding: 'utf-8'
    },
    () => {}
  )
  return results
}

const writeApiDefine = async (apiDefines: any, fileName: string, fileNamePrefix: string) => {
  writeFile(
    resolve(__dirname, `log/apiget/${fileName}${fileNamePrefix}.json`),
    JSON.stringify(apiDefines, null, 2),
    {
      encoding: 'utf-8'
    },
    () => {}
  )
}

const formatApiDefine = (apiDefines: ApiGetResult): FApiGet[] => {
  return Object.keys(apiDefines).map(it => {
    return {
      apiOrigin: it,
      apiFormat: it.replace(/{[^}]+}/g, 'VARIABLE'),
      method: apiDefines[it]
    }
  })
}

export async function runApiGet(fileNamePrefix: string): Promise<FApiGet[]> {
  const devIp = getDevIp()
  emptyDir(resolve(__dirname, 'log/apiget'))
  mkdirp(resolve(__dirname, 'log/apiget'))
  return fetchServerApiDefine(devIp, fileNamePrefix).then(resp => {
    writeApiDefine(resp, 'response', fileNamePrefix)
    const resultApiList = formatApiDefine(resp)
    writeApiDefine(resultApiList, 'formattedUiUse', fileNamePrefix)
    return resultApiList
  })
}
