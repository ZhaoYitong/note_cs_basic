const shell = require('shelljs')
const path = require('path')
const chalk = require('chalk')
const yParser = require('yargs-parser')
const readline = require('readline')
const opener = require('opener')

const config = require('./config')

const { base, subApps } = config
let apps = [base].concat(subApps)

const cwd = process.cwd()
const log = console.log
const argv = yParser(process.argv.slice(2))

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  terminal: false
})

const _chalk = {
  grey: msg => chalk.hex('#e8e8e8')(msg),
  green: msg => chalk.hex('#73d13d')(msg),
  yellow: msg => chalk.hex('#fff566')(msg),
  red: msg => chalk.hex('#ff7875')(msg)
}

if (argv.help) {
  console.log('--help')
  console.log('--skip', _chalk.green('skip build libs'))
  console.log('--apps', _chalk.green('start all'))
  console.log('--apps base,dashboard', _chalk.green('start base,dashboard'))
  console.log('--zstackoem', _chalk.green('NO OEM'))
  console.log('--zstackoem CTStack', _chalk.green('OEM is CTStack'))
  console.log('--hcsooem', _chalk.green('NO OEM'))
  console.log('--hcsooem 安徽电信政务云', _chalk.green('OEM is 安徽电信政务云'))
  console.log('--sso', _chalk.green('login by sso'))
  console.log('--devIp 172.xx.xx.xx', _chalk.green('dev ip:172.xx.xx.xx'))
  console.log('--remoteIp 172.xx.xx.xx', _chalk.green('remote ip:172.xx.xx.xx'))
  process.exit()
}

if (argv.sourcemap) {
  process.env.SOURCE_MAP = true
}

if (argv.zstackoem) {
  process.env.__ZSTACKOEM__ = argv.zstackoem
} else {
  process.env.__ZSTACKOEM__ = 'ZStack Cloud'
}

if (argv.sso) {
  process.env.__SSO__ = true
}

if (argv.exchangeLanguage) {
  process.env.__EXCHANGELANGUAGE__ = true
}

if (argv.branchName) {
  process.env.__BRANCHNAME__ = argv.branchName
}

if (argv.remoteIp) {
  process.env.REMOTEIP = argv.remoteIp
}

if (argv.devIp) {
  process.env.DEVIP = argv.devIp
}

const libs = ['umi', 'components', 'features']

const buildLibs = async () => {
  if (argv.skip) {
    return
  }

  if (argv.manually) {
    shell.cd(path.join(cwd, 'utils'))

    const handleTask = cp =>
      new Promise((resolve, reject) => {
        cp.stdout.on('data', data => {
          log(_chalk.green(('>>>>>', data)))

          const successTags = ['Start watching', 'since file changed']

          if (successTags.some(tag => data.includes(tag))) resolve()
        })
        cp.stderr.on('data', err => {
          log(_chalk.red(err))
        })
        cp.on('error', () => {
          log(_chalk.red(`build libs fail`))
          reject()
        })
      })

    // const cp = shell.exec('yarn build:dev', { async: true })

    // await handleTask(cp)

    const tasks = libs.map(name => {
      shell.cd(path.join(cwd, name))
      const cp = shell.exec('yarn build:dev', { async: true })

      return handleTask(cp)
    })

    await Promise.all(tasks)
  } else {
    shell.cd(cwd)
    const process = shell.exec('yarn build:libs', {
      async: true
    })
    return new Promise((resolve, reject) => {
      process.on('exit', () => {
        console.log('exit')
        resolve()
      })
      process.on('error', () => {
        log(_chalk.red(`build libs fail`))
        reject()
      })
    })
  }
}

const start = rawApps => {
  buildLibs().then(async () => {
    // base项目依赖其他项目编译完成后的结果
    const apps = rawApps.filter(item => item !== base)
    process.env.APPS = apps.map(app => {
      const appNameArr = app.split('/')
      if (appNameArr[0] === 'apps') {
        appNameArr.shift()
      }
      return appNameArr.join('/')
    })
    const successTag = 'Compiled successfully'

    const check = (resolve, timer, app, cbFn) => data => {
      if (data.includes(successTag)) {
        log(chalk.yellow(`${app} 编译耗时👇`))
        console.timeEnd(app)
        resolve()
        clearTimeout(timer)
        cbFn()
      }
    }

    const result = apps.map(app => {
      log(chalk.yellow('start:', app))
      const appPath = path.resolve(cwd, app)
      shell.cd(appPath)
      let execCmd = 'yarn start:self'
      if (argv.remoteIp) {
        execCmd = `cross-env HOST=${argv.remoteIp} ` + execCmd
      }
      const cp = shell.exec(execCmd, { async: true })
      console.time(app)

      return new Promise((resolve, reject) => {
        // NOTE 编译时间超过5分钟，报错处理
        const timer = setTimeout(() => reject(new Error(`${appPath}: timeout`)), 5 * 60000)

        const callback = () => {
          cp.stdout.off('data', binding)
        }
        const binding = check(resolve, timer, app, callback)
        cp.stdout.on('data', binding)
      })
    })

    await Promise.all(result)

    // 编译base
    console.time(config.base)
    await new Promise((resolve, reject) => {
      const base = shell.exec('yarn start:self', {
        async: true,
        cwd: path.join(cwd, config.base)
      })

      const timer = setTimeout(() => reject(new Error('base: timeout')), 5 * 60000)
      const callback = () => {
        base.stdout.off('data', binding)
      }
      const binding = check(resolve, timer, config.base, callback)
      base.stdout.on('data', binding)
    })

    log(chalk.green('>>>>>>>>>>>>>>start successfully>>>>>>>>>>>>>>>>>>'))
    // opener('http://localhost:8000/')
  })
}

if (!argv.apps) {
  log('App列表 \n')
  log('名称'.padEnd(28, ' '), '编号')
  apps.forEach((app, index) => {
    log(app.split('/').pop().padEnd(30, ' '), _chalk.yellow(index + 1))
  })
  log('\n请输入App编号，以英文逗号分隔 \n')

  rl.on('line', line => {
    const appCodes = line.split(',')
    apps = apps.filter((app, index) => {
      return appCodes.indexOf((index + 1).toString()) >= 0
    })
    rl.close()
    start(apps)
  })
} else if (typeof argv.apps === 'string') {
  apps = argv.apps.split(',')
  start(apps)
} else {
  start(apps)
}
