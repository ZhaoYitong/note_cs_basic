const shell = require('shelljs')
const path = require('path')

shell.cp(
  '-f',
  path.resolve(__dirname, 'routes.tpl'),
  path.resolve(
    __dirname,
    '../node_modules/umi/node_modules/@umijs/preset-built-in/lib/plugins/generateFiles/core/routes.tpl'
  )
)

shell.cp(
  '-f',
  path.resolve(__dirname, 'isValidModel.js'),
  path.resolve(__dirname, '../node_modules/@umijs/plugin-dva/lib/getModels/isValidModel.js')
)

shell.cp(
  '-f',
  path.resolve(__dirname, 'localeExports.tpl'),
  path.resolve(__dirname, '../node_modules/@umijs/plugin-locale/lib/templates/localeExports.tpl')
)
