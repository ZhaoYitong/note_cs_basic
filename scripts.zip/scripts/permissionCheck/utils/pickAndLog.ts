import { readdirSync, writeFileSync, unlinkSync, statSync, rmSync } from 'fs'
import { resolve } from 'path'
import mkdirp from 'mkdirp'
import { getFileNamePrefixWithGit, getNodeLoc, wrapLog } from '../../utils'
import type { FormatedNode} from './define';
import { PERMISSION_CONFIG_FILE_PATH } from './define'
import { findPermissionKeyByFile } from './astParse'

const operationKeyDefine: Record<string, string[]> = {}
const menuKeyDefine: Record<string, string[]> = {}

const emptyDir = (path: string) => {
  try {
    const curfiles = readdirSync(path)
    curfiles.forEach(file => {
      const filePath = `${path}/${file}`
      const stats = statSync(filePath)
      if (stats.isDirectory()) {
        emptyDir(filePath)
      } else {
        unlinkSync(filePath)
        console.log(`Remove ${file} success!`)
      }
    })
    rmSync(resolve(__dirname, '../log'), { recursive: true })
  } catch {}
}

const preExec = () => {
  emptyDir(resolve(__dirname, '../log'))
  mkdirp(resolve(__dirname, '../log'))
}

const getFiles = (mainDir: string) => {
  const fileList: any[] = []
  const tranverseFiles = (dir: string, files: string[]) => {
    const entrys = readdirSync(dir, { withFileTypes: true })
    entrys.forEach(dirent => {
      const filePath = resolve(dir, dirent.name)
      if (/apps|components|features|utils|src|pages/.test(filePath)) {
        if (/^((?!node_modules|dist\/|\.history|\.umi|locales).)*$/.test(filePath)) {
          if (dirent.isDirectory()) {
            tranverseFiles(filePath, files)
          } else if (/^((?!\.d\.ts)(?!\.min\.js)(?!\.md).)*(\.ts|\.tsx|\.js)$/.test(filePath)) {
            files.push(filePath)
          }
        }
      }
    })
  }
  tranverseFiles(mainDir, fileList)

  return fileList
}

const formatKeyDefine = (
  logFilePath: string,
  keyDefine: Record<string, string[]>,
  allKeysCommentMap: Record<string, string>,
  originNodes: FormatedNode[] = []
) => {
  const result: {
    single: Record<string, string[]>[]
    repeat: Record<string, string[]>[]
    unused: Record<
      string,
      {
        desc: string
        def: string
      }
    >[]
  } = {
    single: [],
    repeat: [],
    unused: []
  }
  Object.keys(keyDefine).forEach(k => {
    if (keyDefine[k].length === 1) {
      result.single.push({
        [k]: keyDefine[k]
      })
    } else if (keyDefine[k].length > 1) {
      result.repeat.push({
        [k]: keyDefine[k]
      })
    } else {
      result.unused.push({
        [k]: {
          desc: allKeysCommentMap[k],
          def: originNodes.find(n => n.key === k)?.value || ''
        }
      })
    }
  })
  if (result.unused.length > 0) {
    wrapLog.red(
      `WARNING: ${result.unused.length} unused keys, visit ${logFilePath} for more details`
    )
  }
  return result
}

const onFindPermissionKeyFn = (params: any) => {
  const { fileName, nodePath, permissionKey } = params
  const keyPath = getNodeLoc(fileName, nodePath)
  operationKeyDefine[permissionKey].push(keyPath)
}

const onFindMenuKeyFn = (params: any) => {
  const { fileName, nodePath, permissionKey } = params
  const keyPath = getNodeLoc(fileName, nodePath)
  menuKeyDefine[permissionKey].push(keyPath)
}

export const checkKeys = (
  rootDir: string,
  params: {
    allKeysCommentMap: {}
    uiMenuKeys: string[]
    uiBtnKeys: string[]
    menuNodes: FormatedNode[]
    buttonNodes: FormatedNode[]
  }
) => {
  preExec()
  const files = getFiles(rootDir)
  const namePrefix = getFileNamePrefixWithGit()
  params.uiBtnKeys.forEach(k => {
    operationKeyDefine[k] = []
  })
  params.uiMenuKeys.forEach(k => {
    menuKeyDefine[k] = []
  })

  files.forEach(file => {
    try {
      if (file.indexOf(PERMISSION_CONFIG_FILE_PATH) < 0) {
        findPermissionKeyByFile(file, onFindPermissionKeyFn, operationKeyDefine)
        findPermissionKeyByFile(file, onFindMenuKeyFn, menuKeyDefine)
      }
    } catch (e) {
      console.error(file, e)
    }
  })
  const operationLogFilePath = resolve(__dirname, `../log/operationKeyDefine${namePrefix}.log`)
  const menuLogFilePath = resolve(__dirname, `../log/menuKeyDefine${namePrefix}.log`)
  const formatedOperationKeys = formatKeyDefine(
    operationLogFilePath,
    operationKeyDefine,
    params.allKeysCommentMap,
    params.buttonNodes
  )
  const formatedMenuKeys = formatKeyDefine(
    menuLogFilePath,
    menuKeyDefine,
    params.allKeysCommentMap,
    params.buttonNodes
  )

  writeFileSync(operationLogFilePath, JSON.stringify(formatedOperationKeys, null, 2), 'utf-8')
  writeFileSync(menuLogFilePath, JSON.stringify(formatedMenuKeys, null, 2), 'utf-8')
  // TODO: 菜单级的操作权限支持
}
