import { resolve } from 'path'

export const MASTER_APP_PATH = 'apps/base'

export const PERMISSION_CONFIG_FILE_PATH = 'features/src/permission/config.ts'

export const ROOT_DIR = resolve(__dirname, '../../../')

export type TreeNode = {
  id: string
  range: string[]
  name: string
  type: 'menu' | 'button'
  right: string[]
  children: TreeNode[]
}

export type FormatedNode = {
  value: string
  key: string
  comment: string
}
