import { readFileSync } from 'fs'
import { parse } from '@babel/parser'
import type { NodePath } from '@babel/traverse'
import traverse from '@babel/traverse'
import type * as t from '@babel/types'

interface onFindKeyFnParam {
  nodePath: NodePath<t.Node>
  fileName: string
  permissionKey: string
}

export type IOnFindKey = (params: onFindKeyFnParam) => void

export interface IFindPermissionKeyParam {
  ast: t.File
  fileName: string
  onFindKeyFn?: IOnFindKey
  allBtnKeysMap: Record<string, string[]>
}

const findPermissionKeyFn = (params: IFindPermissionKeyParam) => {
  const { ast, fileName, onFindKeyFn, allBtnKeysMap } = params
  const result: any = {
    unparsed: [],
    identifier: [],
    memberExpression: [],
    unstandard: [],
    parseError: []
  }
  traverse(ast, {
    enter(nodePath) {
      if (
        nodePath.node.type === 'StringLiteral' &&
        Array.isArray(allBtnKeysMap[nodePath.node.value])
      ) {
        const btnKey = nodePath.node.value
        try {
          if (onFindKeyFn) {
            onFindKeyFn({
              fileName,
              nodePath,
              permissionKey: btnKey
            })
          }
        } catch (e) {
          console.log(e)
        }
      }
    }
  })
  return result
}

export const findPermissionKeyByFile = (
  fileName: string,
  onFindKeyFn: IOnFindKey,
  allBtnKeysMap: Record<string, string[]>
) => {
  const code = readFileSync(fileName, { encoding: 'utf-8' })
  const ast = parse(code, {
    sourceType: 'module',
    plugins: ['typescript', 'jsx', 'classProperties', 'decorators-legacy']
  })
  const findResults = findPermissionKeyFn({ ast, fileName, onFindKeyFn, allBtnKeysMap })
  return { ast, code, ...findResults }
}
