/**
 * author: yitong.zhao
 * description: 从后端获取数据权限的全量key，生成map，写入文件，从而实现数据权限的自动化生成，开发人员无需手动维护，只要关注业务层面的权限使用
 */
import { join } from 'path'
import { Service } from 'umi'
import { fetchKeysByIp } from './utils/dataFetch'
import { writeOperationConfigs } from './utils/writePermissonMap'
import { MASTER_APP_PATH, ROOT_DIR } from './utils/define'
import { checkKeys } from './utils/pickAndLog'
import { validateDefaultDevIp } from '../utils'

// TODO: 可能需要后端支持，增加分支标识，git commitId hash 标识，git 最后一次提交记录标识...
const newService = new Service({
  // TODO: 这里主应用的路径是写死的，需要解耦，可以尝试用umi的内置方法，直接获取主应用下的DEVIP
  // https://github.com/umijs/umi/blob/3.x/packages/core/src/Config/Config.ts#L40
  cwd: join(process.cwd(), MASTER_APP_PATH)
})
// https://github.com/umijs/umi/blob/3.x/packages/core/src/Service/Service.ts#L180
newService.loadEnv()

const devIp = process.env.DEVIP

validateDefaultDevIp(devIp as string, () => {
  fetchKeysByIp(devIp as string).then(treeNodes => {
    if (!treeNodes) {
      console.error('>>>>>>>>FETCH ERROR!')

      process.exit(1)
    }
    const { uiMenuKeys, uiBtnKeys, allKeysCommentMap, menuNodes, buttonNodes } =
      writeOperationConfigs(treeNodes)
    checkKeys(ROOT_DIR, {
      allKeysCommentMap,
      uiBtnKeys,
      uiMenuKeys,
      menuNodes,
      buttonNodes
    })
  })
})
