## 自动化更新权限配置
`方便开发人员专注业务开发，较少关注权限的配置，关注权限key的注册即可`

#### 权限获取并更新
```bash
$ yarn check:permission
# 获取 DEVIP
# 请求权限数据
# 解析数据
# 写入目标路径 xxx/xxx.ts
```

#### 权限维护（进行中）
- 后续业务代码层不再出现后端定义的权限id，统一通过脚本自动化写入到配置文件，以大写下划线形式连接（eg: vm.rpMgt.remoteConsole -> VM_RP_MGT_REMOTE_CONSOLE）

  - 菜单级（一级、二级和三级）
    - 一级、二级菜单的增删改，后续可直接参考 [MenuPermissionKey](../../features/src/Resources/interface.ts#L67)维护
    - 三级菜单的增删改，相关 permissionId 待替换，参考 [MenuPermissionKey](../../features/src/Resources/interface.ts#L67) 进行维护

  - 操作级
    - 混合复用操作`(如删除操作，对应多种资源，多个页面（多云管理，数据中心管理）)`
      - 后续统一用 [checkResourceOpPermission](../../features/src/utils/common.tsx#L63)维护
    - 单一操作
      - 后续统一用 [noPermissionOfOp](../../features/src/utils/common.tsx#L184)维护
