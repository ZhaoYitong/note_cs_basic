/* eslint-disable no-template-curly-in-string */
/* eslint-disable no-useless-concat */
const fs = require('fs-extra')
const path = require('path')

const base = 'apps/base'
const libs = require('../.fatherrc.js').pkgs
const extraApps = ['demo'].concat(base).concat(libs)

const subApps = []
const prefix = 'apps/'

function walkSync(currentDirPath, callback, deepth = 1) {
  if (currentDirPath.includes('node_modules')) return
  fs.readdirSync(currentDirPath).forEach(function (name) {
    var filePath = path.join(currentDirPath, name)
    if (extraApps.includes(filePath)) return
    var stat = fs.statSync(filePath)
    if (stat.isDirectory()) {
      if (
        fs.existsSync(path.join(filePath, 'package.json')) &&
        fs.existsSync(path.join(filePath, '.env'))
      ) {
        // fix windows sep
        callback(filePath.split(path.sep).join('/'))
      } else {
        walkSync(filePath, callback, deepth + 1)
      }
    }
  })
}

// 遍历目录，生成微应用列表
walkSync('./', function (filePath) {
  if (!filePath.includes(base)) {
    subApps.push(filePath)
  }
})
subApps.sort()

// 遍历微应用生成对应端口号配置
let config = 'export default [\n'
subApps.forEach((appPath, idx) => {
  var filePath = path.join(appPath, '.env')
  const content = fs.readFileSync(filePath, 'utf-8')
  const port = /PORT=([0-9]+)/.exec(content)[1]
  if (appPath.startsWith(prefix)) {
    appPath = appPath.slice(prefix.length)
  }
  const appName = appPath.split('/').join('-')
  config += `  { name: '${appName}', base: '${appPath}', port: ${port} }${
    idx !== subApps.length - 1 ? ',' : ''
  }\n`
})
config += ']\n'
// 要写入的位置
const targetPath = path.join('./', 'utils/src/app.ts')
fs.ensureFileSync(targetPath)
const currentConfig = fs.readFileSync(targetPath, 'utf-8')
// 如果当前配置与生成的不一致，替换配置
if (currentConfig !== config) {
  fs.outputFileSync(targetPath, config)
}

module.exports = {
  libs,
  base,
  subApps,
  prefix
}
