var __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i]
          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p]
        }
        return t
      }
    return __assign.apply(this, arguments)
  }
var __awaiter =
  (this && this.__awaiter) ||
  function (thisArg, _arguments, P, generator) {
    function adopt(value) {
      return value instanceof P
        ? value
        : new P(function (resolve) {
            resolve(value)
          })
    }
    return new (P || (P = Promise))(function (resolve, reject) {
      function fulfilled(value) {
        try {
          step(generator.next(value))
        } catch (e) {
          reject(e)
        }
      }
      function rejected(value) {
        try {
          step(generator['throw'](value))
        } catch (e) {
          reject(e)
        }
      }
      function step(result) {
        result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected)
      }
      step((generator = generator.apply(thisArg, _arguments || [])).next())
    })
  }
var __generator =
  (this && this.__generator) ||
  function (thisArg, body) {
    var _ = {
        label: 0,
        sent: function () {
          if (t[0] & 1) throw t[1]
          return t[1]
        },
        trys: [],
        ops: []
      },
      f,
      y,
      t,
      g
    return (
      (g = { next: verb(0), throw: verb(1), return: verb(2) }),
      typeof Symbol === 'function' &&
        (g[Symbol.iterator] = function () {
          return this
        }),
      g
    )
    function verb(n) {
      return function (v) {
        return step([n, v])
      }
    }
    function step(op) {
      if (f) throw new TypeError('Generator is already executing.')
      while ((g && ((g = 0), op[0] && (_ = 0)), _))
        try {
          if (
            ((f = 1),
            y &&
              (t =
                op[0] & 2
                  ? y['return']
                  : op[0]
                  ? y['throw'] || ((t = y['return']) && t.call(y), 0)
                  : y.next) &&
              !(t = t.call(y, op[1])).done)
          )
            return t
          if (((y = 0), t)) op = [op[0] & 2, t.value]
          switch (op[0]) {
            case 0:
            case 1:
              t = op
              break
            case 4:
              _.label++
              return { value: op[1], done: false }
            case 5:
              _.label++
              y = op[1]
              op = [0]
              continue
            case 7:
              op = _.ops.pop()
              _.trys.pop()
              continue
            default:
              if (
                !((t = _.trys), (t = t.length > 0 && t[t.length - 1])) &&
                (op[0] === 6 || op[0] === 2)
              ) {
                _ = 0
                continue
              }
              if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) {
                _.label = op[1]
                break
              }
              if (op[0] === 6 && _.label < t[1]) {
                _.label = t[1]
                t = op
                break
              }
              if (t && _.label < t[2]) {
                _.label = t[2]
                _.ops.push(op)
                break
              }
              if (t[2]) _.ops.pop()
              _.trys.pop()
              continue
          }
          op = body.call(thisArg, _)
        } catch (e) {
          op = [6, e]
          y = 0
        } finally {
          f = t = 0
        }
      if (op[0] & 5) throw op[1]
      return { value: op[0] ? op[1] : void 0, done: true }
    }
  }
var _this = this
// @ts-nocheck
var express = require('express')
var cors = require('cors') // 引入cors包
var fs = require('fs')
var path = require('path')
var deepl = require('deepl-node')
var app = express()
var port = 8004
var authKey = 'eb227fbc-b27a-4ebf-8362-47764fbc1395:fx' // Replace with your key
var translator = new deepl.Translator(authKey)
var cmpBaseUrl = 'http://172.20.12.62:8100'
var promiseAllLimit = function (n, list) {
  return __awaiter(_this, void 0, void 0, function () {
    var head, tail, result, execute, runNext
    var _this = this
    return __generator(this, function (_a) {
      switch (_a.label) {
        case 0:
          head = list.slice(0, n)
          tail = list.slice(n)
          result = []
          execute = function (promise, i, runNext) {
            return __awaiter(_this, void 0, void 0, function () {
              var _a, _b
              return __generator(this, function (_c) {
                switch (_c.label) {
                  case 0:
                    _a = result
                    _b = i
                    return [4 /*yield*/, promise()]
                  case 1:
                    _a[_b] = _c.sent()
                    return [4 /*yield*/, runNext()]
                  case 2:
                    _c.sent()
                    return [2 /*return*/]
                }
              })
            })
          }
          runNext = function () {
            return __awaiter(_this, void 0, void 0, function () {
              var i, promise
              return __generator(this, function (_a) {
                switch (_a.label) {
                  case 0:
                    i = list.length - tail.length
                    promise = tail.shift()
                    if (!(promise !== undefined)) return [3 /*break*/, 2]
                    return [4 /*yield*/, execute(promise, i, runNext)]
                  case 1:
                    _a.sent()
                    _a.label = 2
                  case 2:
                    return [2 /*return*/]
                }
              })
            })
          }
          return [
            4 /*yield*/,
            Promise.all(
              head.map(function (promise, i) {
                return execute(promise, i, runNext)
              })
            )
          ]
        case 1:
          _a.sent()
          return [2 /*return*/, result]
      }
    })
  })
}
var makeRequest = function (url, method, headers, data) {
  if (headers === void 0) {
    headers = {}
  }
  if (data === void 0) {
    data = null
  }
  var config = {
    url: url,
    method: method,
    headers: headers
  }
  if (['post', 'put', 'patch'].includes(method.toLowerCase())) {
    config.data = data
  } else if (data) {
    config.params = data
  }
  return fetch(url, config)
    .then(function (response) {
      return response.json()
    })
    .catch(function (error) {
      return Promise.reject(error)
    })
}
// node 代码需要优化，暂时先这么low
// 允许所有域的请求，也可以根据需要设置允许的域
app.use(cors())
// 用于解析 JSON 格式的请求体
app.use(express.json({ limit: '50mb' }))
app.use(express.urlencoded({ limit: '50mb', extended: true }))
function updateJsonFile(branch, json) {
  return new Promise(function (resolve, reject) {
    fs.writeFile(
      path.join(__dirname, '/branch/'.concat(branch), 'intl.json'),
      JSON.stringify(json, null, 2),
      'utf8',
      function (err) {
        if (err) {
          reject(err)
        } else {
          console.log('File has been capitalizeJson created intl.json')
          resolve(true)
        }
      }
    )
    fs.writeFile(
      path.join(__dirname, '/branch/'.concat(branch), 'zh-CN.json'),
      JSON.stringify(__assign({}, json['zh-CN']), null, 2),
      'utf8',
      function (err) {
        if (err) {
          reject(err)
        } else {
          console.log('File has been capitalizeJson created zh-CN.json')
          resolve(true)
        }
      }
    )
    fs.writeFile(
      path.join(__dirname, '/branch/'.concat(branch), 'en-US.json'),
      JSON.stringify(__assign({}, json['en-US']), null, 2),
      'utf8',
      function (err) {
        if (err) {
          reject(err)
        } else {
          console.log('File has been capitalizeJson created en-US.json')
          resolve(true)
        }
      }
    )
  })
}
function readJsonFile(branch, pathUrl) {
  if (pathUrl === void 0) {
    pathUrl = 'intl.json'
  }
  return new Promise(function (resolve, reject) {
    fs.readFile(
      path.join(__dirname, '/branch/'.concat(branch), pathUrl),
      'utf-8',
      function (err, data) {
        if (err) {
          reject({ status: 500, msg: 'error', data: 'json文件不存在' })
        } else {
          try {
            resolve({ status: 0, msg: 'success', data: data })
          } catch (parseErr) {
            reject({ status: 500, msg: 'error', data: 'json格式不正确' })
          }
        }
      }
    )
  })
}
function createDir(branch) {
  return new Promise(function (resolve, reject) {
    try {
      fs.mkdirSync(path.join(__dirname, '/branch/'.concat(branch)))
      resolve(true)
      console.log('目录创建成功')
    } catch (error) {
      console.error('创建目录时出错：', error)
      reject(error)
    }
  })
}
// 获取所有的对应版本的key
app.get('/intl/getAllKey', function (req, res) {
  var branch = req.query.branch
  fs.readFile(
    path.join(__dirname, '/branch/'.concat(branch), 'intl.json'),
    'utf-8',
    function (err, data) {
      if (err) {
        res.send({
          status: 500,
          msg: 'error',
          data: 'json解析错误'
        })
        return
      }
      try {
        var jsonData = JSON.parse(data)
        res.send({
          status: 0,
          msg: 'sucess',
          data: jsonData
        })
      } catch (parseErr) {
        console.error('Error parsing JSON:', parseErr)
        res.send({
          status: 500,
          msg: 'error',
          data: 'json解析错误'
        })
      }
    }
  )
})
//  save
app.post('/intl/save', function (req, res) {
  var json
  // 获取请求体中的参数
  var _a = req.body,
    key = _a.key,
    zh = _a.zh,
    en = _a.en,
    branch = _a.branch,
    replaceAll = _a.replaceAll,
    search = _a.search
  // 这里可以添加处理逻辑，例如保存到数据库等
  fs.readFile(
    path.join(__dirname, '/branch/'.concat(branch), 'intl.json'),
    'utf-8',
    function (err, data) {
      if (err) {
        res.send({
          status: 500,
          msg: 'error',
          data: 'json解析错误'
        })
        return
      }
      try {
        json = JSON.parse(data)
        if (json) {
          try {
            if (lodash.isEmpty(search)) {
              if (replaceAll) {
                var zhCnList = Object.keys(json['zh-CN']).map(function (k) {
                  return {
                    key: k,
                    value: json['zh-CN'][k]
                  }
                })
                var enUsList = Object.keys(json['en-US']).map(function (k) {
                  return {
                    key: k,
                    value: json['en-US'][k]
                  }
                })
                var orginZh_1 = json['zh-CN'][key]
                var orginEn_1 = json['en-US'][key]
                var zhAll = zhCnList.filter(function (zh) {
                  return lodash.isEqual(zh.value, orginZh_1)
                })
                var enAll = enUsList.filter(function (en) {
                  return lodash.isEqual(en.value, orginEn_1)
                })
                if (zhAll.length) {
                  zhAll.map(function (item) {
                    json['zh-CN'][item.key] = zh
                  })
                } else {
                  json['zh-CN'][key] = zh
                }
                if (enAll.length) {
                  enAll.map(function (item) {
                    json['en-US'][item.key] = en
                  })
                } else {
                  json['en-US'][key] = en
                }
              } else {
                json['zh-CN'][key] = zh
                json['en-US'][key] = en
              }
            } else {
              if (!json['zh-CN'][search] || !json['en-US'][search]) {
                res.send({
                  status: 500,
                  msg: 'error',
                  data: '非法key'
                })
              } else {
                json['zh-CN'][search] = zh
                json['en-US'][search] = en
              }
            }
            fs.writeFile(
              path.join(__dirname, '/branch/'.concat(branch), 'intl.json'),
              JSON.stringify(json, null, 2),
              'utf8',
              function (err) {
                if (err) {
                  res.send({
                    status: 500,
                    msg: 'error',
                    data: 'json文件写入失败'
                  })
                  return
                }
                try {
                  res.send({
                    status: 0,
                    msg: 'sucess',
                    data: json
                  })
                } catch (parseErr) {
                  console.error('Error parsing JSON:', parseErr)
                  res.send({
                    status: 500,
                    msg: 'error',
                    data: 'json解析错误'
                  })
                }
              }
            )
            fs.writeFile(
              path.join(__dirname, '/branch/'.concat(branch), 'zh-CN.json'),
              JSON.stringify(json['zh-CN'], null, 2),
              'utf8',
              function (err) {
                if (err) {
                  res.send({
                    status: 500,
                    msg: 'error',
                    data: 'json文件写入失败'
                  })
                  return
                }
                try {
                  console.log('File has been created zh-CN.json')
                } catch (parseErr) {
                  console.error('Error parsing JSON:', parseErr)
                  res.send({
                    status: 500,
                    msg: 'error',
                    data: 'json解析错误'
                  })
                }
              }
            )
            fs.writeFile(
              path.join(__dirname, '/branch/'.concat(branch), 'en-US.json'),
              JSON.stringify(json['en-US'], null, 2),
              'utf8',
              function (err) {
                if (err) {
                  res.send({
                    status: 500,
                    msg: 'error',
                    data: 'json文件写入失败'
                  })
                  return
                }
                try {
                  console.log('File has been created en-US.json')
                } catch (parseErr) {
                  console.error('Error parsing JSON:', parseErr)
                  res.send({
                    status: 500,
                    msg: 'error',
                    data: 'json解析错误'
                  })
                }
              }
            )
          } catch (err) {
            res.send({
              status: 500,
              msg: 'error',
              data: 'json文件写入失败'
            })
          }
        }
      } catch (parseErr) {
        console.error('Error parsing JSON:', parseErr)
        res.send({
          status: 500,
          msg: 'error',
          data: 'json解析错误'
        })
      }
    }
  )
})
// 创建对应分支的文件夹
// @ts-ignore
app.get('/createDir', function (req, res) {
  var branch = req.query.branch
  if (branch) {
    try {
      fs.mkdirSync(path.join(__dirname, '/branch/'.concat(branch)))
      res.send({
        status: 0,
        msg: 'sucess',
        data: '\u76EE\u5F55 '.concat(branch, ' \u521B\u5EFA\u6210\u529F\u3002')
      })
    } catch (err) {
      res.send({
        status: 500,
        msg: 'error',
        data: '\u76EE\u5F55 '.concat(branch, ' \u521B\u5EFA\u5931\u8D25\u3002')
      })
    }
  } else {
    res.send({
      status: 500,
      msg: 'error',
      data: 'branch必传'
    })
  }
})
// 脚步扫描 同步
app.post('/intl/sync', function (req, res) {
  return __awaiter(_this, void 0, void 0, function () {
    var json, branch, url, jsonDataSource, readFileObject, zhCnkeys, enUskeys, parseErr_1
    var _this = this
    return __generator(this, function (_a) {
      switch (_a.label) {
        case 0:
          branch = req.query.branch
          url = req.query.cmpBaseUrl || cmpBaseUrl
          jsonDataSource = req.body
          return [
            4 /*yield*/,
            readJsonFile(branch).catch(function (err) {
              return __awaiter(_this, void 0, void 0, function () {
                var status, readFile
                return __generator(this, function (_a) {
                  switch (_a.label) {
                    case 0:
                      status = err.status
                      if (!(status === 500)) return [3 /*break*/, 4]
                      // 创建对应分支的文件夹
                      return [
                        4 /*yield*/,
                        createDir(branch)
                        // 写入文件
                      ]
                    case 1:
                      // 创建对应分支的文件夹
                      _a.sent()
                      // 写入文件
                      return [4 /*yield*/, updateJsonFile(branch, jsonDataSource)]
                    case 2:
                      // 写入文件
                      _a.sent()
                      return [4 /*yield*/, readJsonFile(branch)]
                    case 3:
                      readFile = _a.sent()
                      res.send({
                        status: readFile.status,
                        msg: readFile.msg,
                        data:
                          readFile.status == 500
                            ? ''.concat(branch, ' json\u6587\u4EF6\u5199\u5165\u5931\u8D25')
                            : ''.concat(branch, ' json\u6587\u4EF6\u5199\u5165\u6210\u529F')
                      })
                      _a.label = 4
                    case 4:
                      return [2 /*return*/]
                  }
                })
              })
            })
          ]
        case 1:
          readFileObject = _a.sent()
          if (!readFileObject) return [3 /*break*/, 6]
          zhCnkeys = Object.keys(jsonDataSource['zh-CN'])
          enUskeys = Object.keys(jsonDataSource['en-US'])
          _a.label = 2
        case 2:
          _a.trys.push([2, 5, , 6])
          json = JSON.parse(
            readFileObject === null || readFileObject === void 0 ? void 0 : readFileObject.data
          )
          zhCnkeys.map(function (key) {
            if (!json['zh-CN'][key]) {
              json['zh-CN'][key] = jsonDataSource['zh-CN'][key]
            }
          })
          enUskeys.map(function (key) {
            if (!json['en-US'][key]) {
              json['en-US'][key] = jsonDataSource['en-US'][key]
            }
          })
          return [4 /*yield*/, translate(url, json)]
        case 3:
          _a.sent()
          return [4 /*yield*/, updateJsonFile(branch, json)]
        case 4:
          _a.sent()
          res.send({
            status: 0,
            msg: 'sucess',
            data: ''.concat(branch, ' json\u6587\u4EF6\u540C\u6B65\u6210\u529F')
          })
          return [3 /*break*/, 6]
        case 5:
          parseErr_1 = _a.sent()
          console.error('Error parsing JSON:', parseErr_1)
          res.send({
            status: 500,
            msg: 'error',
            data: 'json解析错误'
          })
          return [3 /*break*/, 6]
        case 6:
          return [2 /*return*/]
      }
    })
  })
})
function translate(cmpBaseUrl, json) {
  var _this = this
  return new Promise(function (resolve, reject) {
    return __awaiter(_this, void 0, void 0, function () {
      var getCmpToken,
        token,
        cmpConfigHeaders,
        actionInfo,
        genMenusJson,
        queryButtonGroupVoI18n,
        taskKeyI18n,
        stepKeyI18n,
        renameActionInfo,
        renameTaskKeyI18n,
        renameEndConfig,
        keys,
        results,
        actionZhValue,
        actionEnValue,
        menuZhValue,
        menuEnValue,
        key,
        key,
        key
      var _this = this
      return __generator(this, function (_a) {
        switch (_a.label) {
          case 0:
            return [
              4 /*yield*/,
              makeRequest(
                ''.concat(cmpBaseUrl, '/base/v4/pub/token/GetToken'),
                'POST',
                {
                  headers: {
                    'Content-Type': 'application/json'
                  }
                },
                {
                  username: 'admin',
                  password: 'password'
                }
              )
            ]
          case 1:
            getCmpToken = _a.sent()
            token = getCmpToken.data.data.token
            cmpConfigHeaders = {
              Authorization: 'Bearer '.concat(token), // 例如，添加认证令牌
              'X-Vdc-Id': '7c54bc609ffa49caa47f8d22f4d07672'
            }
            return [
              4 /*yield*/,
              makeRequest(
                ''.concat(cmpBaseUrl, '/base/v4/debug/actionInfo'),
                'GET',
                cmpConfigHeaders
              )
            ]
          case 2:
            actionInfo = _a.sent()
            return [
              4 /*yield*/,
              makeRequest(
                ''.concat(cmpBaseUrl, '/base/v4/debug/genMenusJson?format=flat'),
                'GET',
                cmpConfigHeaders
              )
            ]
          case 3:
            genMenusJson = _a.sent()
            return [
              4 /*yield*/,
              makeRequest(
                ''.concat(cmpBaseUrl, '/base/v4/debug/queryButtonGroupVoI18n'),
                'GET',
                cmpConfigHeaders
              )
            ]
          case 4:
            queryButtonGroupVoI18n = _a.sent()
            return [
              4 /*yield*/,
              makeRequest(
                ''.concat(cmpBaseUrl, '/base/v4/debug/taskKeyI18n'),
                'GET',
                cmpConfigHeaders
              )
            ]
          case 5:
            taskKeyI18n = _a.sent()
            return [
              4 /*yield*/,
              makeRequest(
                ''.concat(cmpBaseUrl, '/base/v4/debug/stepKeyI18n'),
                'GET',
                cmpConfigHeaders
              )
            ]
          case 6:
            stepKeyI18n = _a.sent()
            renameActionInfo = lodash.mapKeys(actionInfo.data.data, function (_, key) {
              return 'cmp-actionKey-'.concat(key)
            })
            renameTaskKeyI18n = lodash.mapKeys(taskKeyI18n.data.data, function (_, key) {
              return 'cmp-taskKey-'.concat(key)
            })
            renameEndConfig = Object.assign(
              {},
              renameActionInfo,
              genMenusJson.data.data,
              queryButtonGroupVoI18n.data.data,
              renameTaskKeyI18n,
              stepKeyI18n.data.data
            )
            keys = Object.keys(renameEndConfig)
            results = {}
            return [
              4 /*yield*/,
              promiseAllLimit(
                50,
                keys.map(function (k) {
                  return function () {
                    return __awaiter(_this, void 0, void 0, function () {
                      var str, result
                      return __generator(this, function (_a) {
                        switch (_a.label) {
                          case 0:
                            str = renameEndConfig[k]
                            if (!str) return [3 /*break*/, 2]
                            return [
                              4 /*yield*/,
                              translator.translateText(str, null, 'en-US')
                              // @ts-ignore
                            ]
                          case 1:
                            result = _a.sent()
                            // @ts-ignore
                            results[k] = result.text
                            return [3 /*break*/, 3]
                          case 2:
                            results[k] = ''
                            _a.label = 3
                          case 3:
                            return [2 /*return*/]
                        }
                      })
                    })
                  }
                })
              )
            ]
          case 7:
            _a.sent()
            try {
              actionZhValue = {}
              actionEnValue = {}
              menuZhValue = {}
              menuEnValue = {}
              for (key in actionInfo.data.data) {
                if (json['zh-CN'][key]) {
                  if (!json['zh-CN']['cmp-actionKey-'.concat(key)]) {
                    actionZhValue['cmp-actionKey-'.concat(key)] = json['zh-CN'][key]
                    delete json['zh-CN'][key]
                  }
                }
                if (json['en-US'][key]) {
                  if (!json['en-US']['cmp-actionKey-'.concat(key)]) {
                    actionEnValue['cmp-actionKey-'.concat(key)] = json['en-US'][key]
                    delete json['en-US'][key]
                  }
                }
              }
              for (key in taskKeyI18n.data.data) {
                if (json['zh-CN'][key]) {
                  if (!json['zh-CN']['cmp-taskKey-'.concat(key)]) {
                    actionZhValue['cmp-taskKey-'.concat(key)] = json['zh-CN'][key]
                    delete json['zh-CN'][key]
                  }
                }
                if (json['en-US'][key]) {
                  if (!json['en-US']['cmp-taskKey-'.concat(key)]) {
                    actionEnValue['cmp-taskKey-'.concat(key)] = json['en-US'][key]
                    delete json['en-US'][key]
                  }
                }
              }
              for (key in genMenusJson.data.data) {
                if (json['zh-CN'][key]) {
                  menuZhValue[key] = json['zh-CN'][key]
                }
                if (json['en-US'][key]) {
                  menuEnValue[key] = json['en-US'][key]
                }
              }
              json['zh-CN'] = __assign(
                __assign(__assign(__assign({}, json['zh-CN']), renameEndConfig), actionZhValue),
                menuZhValue
              )
              json['en-US'] = __assign(
                __assign(__assign(__assign({}, json['en-US']), results), actionEnValue),
                menuEnValue
              )
              resolve(json)
            } catch (error) {
              reject(error)
            }
            return [2 /*return*/]
        }
      })
    })
  })
}
// 翻译
app.get('/translate', function (req, res) {
  return __awaiter(_this, void 0, void 0, function () {
    var branch,
      url,
      getCmpToken,
      token,
      cmpConfigHeaders,
      actionInfo,
      genMenusJson,
      queryButtonGroupVoI18n,
      taskKeyI18n,
      stepKeyI18n,
      renameActionInfo,
      renameTaskKeyI18n,
      renameEndConfig,
      keys,
      results
    var _this = this
    return __generator(this, function (_a) {
      switch (_a.label) {
        case 0:
          branch = req.query.branch
          url = req.query.cmpBaseUrl || cmpBaseUrl
          return [
            4 /*yield*/,
            makeRequest(
              ''.concat(url, '/base/v4/pub/token/GetToken'),
              'POST',
              {
                headers: {
                  'Content-Type': 'application/json'
                }
              },
              {
                username: 'admin',
                password: 'password'
              }
            )
          ]
        case 1:
          getCmpToken = _a.sent()
          token = getCmpToken.data.data.token
          cmpConfigHeaders = {
            Authorization: 'Bearer '.concat(token), // 例如，添加认证令牌
            'X-Vdc-Id': '7c54bc609ffa49caa47f8d22f4d07672'
          }
          return [
            4 /*yield*/,
            makeRequest(''.concat(url, '/base/v4/debug/actionInfo'), 'GET', cmpConfigHeaders)
          ]
        case 2:
          actionInfo = _a.sent()
          return [
            4 /*yield*/,
            makeRequest(
              ''.concat(url, '/base/v4/debug/genMenusJson?format=flat'),
              'GET',
              cmpConfigHeaders
            )
          ]
        case 3:
          genMenusJson = _a.sent()
          return [
            4 /*yield*/,
            makeRequest(
              ''.concat(url, '/base/v4/debug/queryButtonGroupVoI18n'),
              'GET',
              cmpConfigHeaders
            )
          ]
        case 4:
          queryButtonGroupVoI18n = _a.sent()
          return [
            4 /*yield*/,
            makeRequest(''.concat(url, '/base/v4/debug/taskKeyI18n'), 'GET', cmpConfigHeaders)
          ]
        case 5:
          taskKeyI18n = _a.sent()
          return [
            4 /*yield*/,
            makeRequest(''.concat(url, '/base/v4/debug/stepKeyI18n'), 'GET', cmpConfigHeaders)
          ]
        case 6:
          stepKeyI18n = _a.sent()
          renameActionInfo = lodash.mapKeys(actionInfo.data.data, function (_, key) {
            return 'cmp-actionKey-'.concat(key)
          })
          renameTaskKeyI18n = lodash.mapKeys(taskKeyI18n.data.data, function (_, key) {
            return 'cmp-taskKey-'.concat(key)
          })
          renameEndConfig = Object.assign(
            {},
            renameActionInfo,
            genMenusJson.data.data,
            queryButtonGroupVoI18n.data.data,
            renameTaskKeyI18n,
            stepKeyI18n.data.data
          )
          keys = Object.keys(renameEndConfig)
          results = {}
          return [
            4 /*yield*/,
            promiseAllLimit(
              50,
              keys.map(function (k) {
                return function () {
                  return __awaiter(_this, void 0, void 0, function () {
                    var str, result
                    return __generator(this, function (_a) {
                      switch (_a.label) {
                        case 0:
                          str = renameEndConfig[k]
                          if (!str) return [3 /*break*/, 2]
                          return [
                            4 /*yield*/,
                            translator.translateText(str, null, 'en-US')
                            // @ts-ignore
                          ]
                        case 1:
                          result = _a.sent()
                          // @ts-ignore
                          results[k] = result.text
                          return [3 /*break*/, 3]
                        case 2:
                          results[k] = ''
                          _a.label = 3
                        case 3:
                          return [2 /*return*/]
                      }
                    })
                  })
                }
              })
            )
          ]
        case 7:
          _a.sent()
          fs.readFile(
            path.join(__dirname, '/branch/'.concat(branch), 'intl.json'),
            'utf-8',
            function (err, data) {
              return __awaiter(_this, void 0, void 0, function () {
                var json,
                  actionZhValue,
                  actionEnValue,
                  menuZhValue,
                  menuEnValue,
                  key,
                  key,
                  key,
                  err_1,
                  parseErr_2
                return __generator(this, function (_a) {
                  switch (_a.label) {
                    case 0:
                      if (err) {
                        res.send({
                          status: 500,
                          msg: 'error',
                          data: 'json解析错误'
                        })
                        return [2 /*return*/]
                      }
                      _a.label = 1
                    case 1:
                      _a.trys.push([1, 6, , 7])
                      json = JSON.parse(data)
                      actionZhValue = {}
                      actionEnValue = {}
                      menuZhValue = {}
                      menuEnValue = {}
                      for (key in actionInfo.data.data) {
                        if (json['zh-CN'][key]) {
                          actionZhValue['cmp-actionKey-'.concat(key)] = json['zh-CN'][key]
                          delete json['zh-CN'][key]
                        }
                        if (json['en-US'][key]) {
                          actionEnValue['cmp-actionKey-'.concat(key)] = json['en-US'][key]
                          delete json['en-US'][key]
                        }
                      }
                      for (key in taskKeyI18n.data.data) {
                        if (json['zh-CN'][key]) {
                          actionZhValue['cmp-taskKey-'.concat(key)] = json['zh-CN'][key]
                          delete json['zh-CN'][key]
                        }
                        if (json['en-US'][key]) {
                          actionEnValue['cmp-taskKey-'.concat(key)] = json['en-US'][key]
                          delete json['en-US'][key]
                        }
                      }
                      for (key in genMenusJson.data.data) {
                        if (json['zh-CN'][key]) {
                          menuZhValue[key] = json['zh-CN'][key]
                        }
                        if (json['en-US'][key]) {
                          menuEnValue[key] = json['en-US'][key]
                        }
                      }
                      if (!json) return [3 /*break*/, 5]
                      _a.label = 2
                    case 2:
                      _a.trys.push([2, 4, , 5])
                      json['zh-CN'] = __assign(
                        __assign(
                          __assign(__assign({}, json['zh-CN']), renameEndConfig),
                          actionZhValue
                        ),
                        menuZhValue
                      )
                      json['en-US'] = __assign(
                        __assign(__assign(__assign({}, json['en-US']), results), actionEnValue),
                        menuEnValue
                      )
                      return [4 /*yield*/, updateJsonFile(branch, json)]
                    case 3:
                      _a.sent()
                      res.send({
                        status: 0,
                        msg: 'sucess',
                        data: ''.concat(branch, ' json\u6587\u4EF6\u540C\u6B65\u6210\u529F')
                      })
                      return [3 /*break*/, 5]
                    case 4:
                      err_1 = _a.sent()
                      res.send({
                        status: 500,
                        msg: 'error',
                        data: 'json文件写入失败'
                      })
                      return [3 /*break*/, 5]
                    case 5:
                      return [3 /*break*/, 7]
                    case 6:
                      parseErr_2 = _a.sent()
                      console.error('Error parsing JSON:', parseErr_2)
                      res.send({
                        status: 500,
                        msg: 'error',
                        data: 'json解析错误'
                      })
                      return [3 /*break*/, 7]
                    case 7:
                      return [2 /*return*/]
                  }
                })
              })
            }
          )
          return [2 /*return*/]
      }
    })
  })
})
// 递归遍历JSON对象，转换英文单词的首字母为大写
function capitalizeWords(obj) {
  for (var key in obj) {
    if (typeof obj[key] === 'string') {
      if (obj[key].indexOf('{') > -1) {
        obj[key] = obj[key].replace(/\{[a-zA-Z]/gi, function (char) {
          return char.toLowerCase()
        })
      } else {
        obj[key] = obj[key].replace(/\b[a-z]/gi, function (char) {
          return char.toUpperCase()
        })
      }
    } else if (typeof obj[key] === 'object') {
      capitalizeWords(obj[key])
    }
  }
}
// 英文首字母大写
// @ts-ignore
app.get('/capitalizeJson', function (req, res) {
  return __awaiter(_this, void 0, void 0, function () {
    var branch
    return __generator(this, function (_a) {
      branch = req.query.branch
      // @ts-ignore
      fs.readFile(
        path.join(__dirname, '/branch/'.concat(branch), 'intl.json'),
        'utf-8',
        function (err, data) {
          if (err) {
            res.send({
              status: 500,
              msg: 'error',
              data: 'json解析错误'
            })
            return
          }
          try {
            var json_1 = JSON.parse(data)
            if (json_1) {
              try {
                capitalizeWords(json_1)
                fs.writeFile(
                  path.join(__dirname, '/branch/'.concat(branch), 'intl.json'),
                  JSON.stringify(json_1, null, 2),
                  'utf8',
                  function (err) {
                    if (err) {
                      res.send({
                        status: 500,
                        msg: 'error',
                        data: 'json文件写入失败'
                      })
                      return
                    }
                    try {
                      console.log('File has been capitalizeJson created intl.json')
                      res.send({
                        status: 0,
                        msg: 'sucess',
                        data: json_1
                      })
                    } catch (parseErr) {
                      console.error('Error parsing JSON:', parseErr)
                      res.send({
                        status: 500,
                        msg: 'error',
                        data: 'json解析错误'
                      })
                    }
                  }
                )
                fs.writeFile(
                  path.join(__dirname, '/branch/'.concat(branch), 'zh-CN.json'),
                  JSON.stringify(__assign({}, json_1['zh-CN']), null, 2),
                  'utf8',
                  function (err) {
                    if (err) {
                      res.send({
                        status: 500,
                        msg: 'error',
                        data: 'json文件写入失败'
                      })
                      return
                    }
                    try {
                      console.log('File has been capitalizeJson created zh-CN.json')
                    } catch (parseErr) {
                      console.error('Error parsing JSON:', parseErr)
                      res.send({
                        status: 500,
                        msg: 'error',
                        data: 'json解析错误'
                      })
                    }
                  }
                )
                fs.writeFile(
                  path.join(__dirname, '/branch/'.concat(branch), 'en-US.json'),
                  JSON.stringify(__assign({}, json_1['en-US']), null, 2),
                  'utf8',
                  function (err) {
                    if (err) {
                      res.send({
                        status: 500,
                        msg: 'error',
                        data: 'json文件写入失败'
                      })
                      return
                    }
                    try {
                      console.log('File has been capitalizeJson created en-US.json')
                    } catch (parseErr) {
                      console.error('Error parsing JSON:', parseErr)
                      res.send({
                        status: 500,
                        msg: 'error',
                        data: 'json解析错误'
                      })
                    }
                  }
                )
              } catch (err) {
                res.send({
                  status: 500,
                  msg: 'error',
                  data: 'json文件写入失败'
                })
              }
            }
          } catch (parseErr) {
            console.error('Error parsing JSON:', parseErr)
            res.send({
              status: 500,
              msg: 'error',
              data: 'json解析错误'
            })
          }
        }
      )
      return [2 /*return*/]
    })
  })
})
// 修改intl
// @ts-ignore
app.post('/intl/en/editor', function (req, res) {
  return __awaiter(_this, void 0, void 0, function () {
    var branch, jsonDataSource
    return __generator(this, function (_a) {
      branch = req.query.branch
      jsonDataSource = req.body
      fs.readFile(
        path.join(__dirname, '/branch/'.concat(branch), 'intl.json'),
        'utf-8',
        function (err, data) {
          if (err) {
            res.send({
              status: 500,
              msg: 'error',
              data: 'json解析错误'
            })
            return
          }
          try {
            var json_2 = JSON.parse(data)
            if (json_2) {
              try {
                Object.keys(jsonDataSource).forEach(function (key) {
                  json_2['en-US'][key] = jsonDataSource[key]
                })
                fs.writeFile(
                  path.join(__dirname, '/branch/'.concat(branch), 'intl.json'),
                  JSON.stringify(json_2, null, 2),
                  'utf8',
                  function (err) {
                    if (err) {
                      res.send({
                        status: 500,
                        msg: 'error',
                        data: 'json文件写入失败'
                      })
                      return
                    }
                    try {
                      console.log('File has been capitalizeJson created intl.json')
                      res.send({
                        status: 0,
                        msg: 'sucess',
                        data: json_2
                      })
                    } catch (parseErr) {
                      console.error('Error parsing JSON:', parseErr)
                      res.send({
                        status: 500,
                        msg: 'error',
                        data: 'json解析错误'
                      })
                    }
                  }
                )
                fs.writeFile(
                  path.join(__dirname, '/branch/'.concat(branch), 'zh-CN.json'),
                  JSON.stringify(__assign({}, json_2['zh-CN']), null, 2),
                  'utf8',
                  function (err) {
                    if (err) {
                      res.send({
                        status: 500,
                        msg: 'error',
                        data: 'json文件写入失败'
                      })
                      return
                    }
                    try {
                      console.log('File has been capitalizeJson created zh-CN.json')
                    } catch (parseErr) {
                      console.error('Error parsing JSON:', parseErr)
                      res.send({
                        status: 500,
                        msg: 'error',
                        data: 'json解析错误'
                      })
                    }
                  }
                )
                fs.writeFile(
                  path.join(__dirname, '/branch/'.concat(branch), 'en-US.json'),
                  JSON.stringify(__assign({}, json_2['en-US']), null, 2),
                  'utf8',
                  function (err) {
                    if (err) {
                      res.send({
                        status: 500,
                        msg: 'error',
                        data: 'json文件写入失败'
                      })
                      return
                    }
                    try {
                      console.log('File has been capitalizeJson created en-US.json')
                    } catch (parseErr) {
                      console.error('Error parsing JSON:', parseErr)
                      res.send({
                        status: 500,
                        msg: 'error',
                        data: 'json解析错误'
                      })
                    }
                  }
                )
              } catch (err) {
                res.send({
                  status: 500,
                  msg: 'error',
                  data: 'json文件写入失败'
                })
              }
            }
          } catch (parseErr) {
            console.error('Error parsing JSON:', parseErr)
            res.send({
              status: 500,
              msg: 'error',
              data: 'json解析错误'
            })
          }
        }
      )
      return [2 /*return*/]
    })
  })
})
app.listen(port, function () {
  console.log('Mock API server is running at http://localhost:'.concat(port))
})
