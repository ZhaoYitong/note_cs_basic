// @ts-nocheck
const express = require('express')
const cors = require('cors') // 引入cors包
const fs = require('fs')
const path = require('path')
const deepl = require('deepl-node')

const app = express()
const port = 8004
const authKey = 'eb227fbc-b27a-4ebf-8362-47764fbc1395:fx' // Replace with your key
const translator = new deepl.Translator(authKey)
const cmpBaseUrl = 'http://172.20.12.62:8100'

type MixJson = {
  'zh-CN': Record<string, string>
  'en-US': Record<string, string>
}

const promiseAllLimit = async <T>(n: number, list: (() => Promise<T>)[]) => {
  const head = list.slice(0, n)
  const tail = list.slice(n)
  const result: T[] = []
  const execute = async (promise: () => Promise<T>, i: number, runNext: () => Promise<void>) => {
    result[i] = await promise()
    await runNext()
  }
  const runNext = async () => {
    const i = list.length - tail.length
    const promise = tail.shift()
    if (promise !== undefined) {
      await execute(promise, i, runNext)
    }
  }
  await Promise.all(head.map((promise, i) => execute(promise, i, runNext)))
  return result
}

const makeRequest = (url: string, method: 'GET' | 'POST', headers = {}, data: any = null) => {
  const config: {
    url: string
    method: 'GET' | 'POST'
    headers: any
    data?: any
    params?: any
  } = {
    url,
    method,
    headers
  }

  if (['post', 'put', 'patch'].includes(method.toLowerCase())) {
    config.data = data
  } else if (data) {
    config.params = data
  }

  return fetch(url, config)
    .then(response => response.json())
    .catch(error => Promise.reject(error))
}

// node 代码需要优化，暂时先这么low

// 允许所有域的请求，也可以根据需要设置允许的域
app.use(cors())
// 用于解析 JSON 格式的请求体
app.use(express.json({ limit: '50mb' }))
app.use(express.urlencoded({ limit: '50mb', extended: true }))

function updateJsonFile(branch: string, json: MixJson) {
  return new Promise((resolve, reject) => {
    fs.writeFile(
      path.join(__dirname, `/branch/${branch}`, 'intl.json'),
      JSON.stringify(json, null, 2),
      'utf8',
      (err: any) => {
        if (err) {
          reject(err)
        } else {
          console.log('File has been capitalizeJson created intl.json')
          resolve(true)
        }
      }
    )

    fs.writeFile(
      path.join(__dirname, `/branch/${branch}`, 'zh-CN.json'),
      JSON.stringify({ ...json['zh-CN'] }, null, 2),
      'utf8',
      (err: any) => {
        if (err) {
          reject(err)
        } else {
          console.log('File has been capitalizeJson created zh-CN.json')
          resolve(true)
        }
      }
    )

    fs.writeFile(
      path.join(__dirname, `/branch/${branch}`, 'en-US.json'),
      JSON.stringify({ ...json['en-US'] }, null, 2),
      'utf8',
      (err: any) => {
        if (err) {
          reject(err)
        } else {
          console.log('File has been capitalizeJson created en-US.json')
          resolve(true)
        }
      }
    )
  })
}

function readJsonFile(
  branch: string,
  pathUrl: string = 'intl.json'
): Promise<{
  status: number
  msg: string
  data: any
}> {
  return new Promise((resolve, reject) => {
    fs.readFile(
      path.join(__dirname, `/branch/${branch}`, pathUrl),
      'utf-8',
      (err: any, data: any) => {
        if (err) {
          reject({ status: 500, msg: 'error', data: 'json文件不存在' })
        } else {
          try {
            resolve({ status: 0, msg: 'success', data })
          } catch (parseErr) {
            reject({ status: 500, msg: 'error', data: 'json格式不正确' })
          }
        }
      }
    )
  })
}

function createDir(branch: string) {
  return new Promise((resolve, reject) => {
    try {
      fs.mkdirSync(path.join(__dirname, `/branch/${branch}`))
      resolve(true)
      console.log('目录创建成功')
    } catch (error) {
      console.error('创建目录时出错：', error)
      reject(error)
    }
  })
}

// 获取所有的对应版本的key
app.get('/intl/getAllKey', (req: any, res: any) => {
  const branch = req.query.branch
  fs.readFile(
    path.join(__dirname, `/branch/${branch}`, 'intl.json'),
    'utf-8',
    (err: any, data: any) => {
      if (err) {
        res.send({
          status: 500,
          msg: 'error',
          data: 'json解析错误'
        })
        return
      }

      try {
        const jsonData = JSON.parse(data)
        res.send({
          status: 0,
          msg: 'sucess',
          data: jsonData
        })
      } catch (parseErr) {
        console.error('Error parsing JSON:', parseErr)
        res.send({
          status: 500,
          msg: 'error',
          data: 'json解析错误'
        })
      }
    }
  )
})

//  save
app.post('/intl/save', (req: any, res: any) => {
  let json: MixJson
  // 获取请求体中的参数
  const { key, zh, en, branch, replaceAll, search } = req.body
  // 这里可以添加处理逻辑，例如保存到数据库等
  fs.readFile(
    path.join(__dirname, `/branch/${branch}`, 'intl.json'),
    'utf-8',
    (err: any, data: any) => {
      if (err) {
        res.send({
          status: 500,
          msg: 'error',
          data: 'json解析错误'
        })
        return
      }

      try {
        json = JSON.parse(data)
        if (json) {
          try {
            if (lodash.isEmpty(search)) {
              if (replaceAll) {
                const zhCnList = Object.keys(json['zh-CN']).map(k => ({
                  key: k,
                  value: json['zh-CN'][k]
                })).filter(zh => zh['key'] === key)

                const enUsList = Object.keys(json['en-US']).map(k => ({
                  key: k,
                  value: json['en-US'][k]
                })).filter(en => en['key'] === key)

                // const orginZh = json['zh-CN'][key]

                // const orginEn = json['en-US'][key]

                // const zhAll = zhCnList.filter(zh => zh['key'] === key)

                // const enAll = enUsList.filter(en => en['key'] === key)

                if (zhCnList.length) {
                  zhCnList.map(item => {
                    json['zh-CN'][item.key] = zh
                  })
                } else {
                  json['zh-CN'][key] = zh
                }

                if (enUsList.length) {
                  enUsList.map(item => {
                    json['en-US'][item.key] = en
                  })
                } else {
                  json['en-US'][key] = en
                }



              } else {
                json['zh-CN'][key] = zh
                json['en-US'][key] = en
              }
            } else {
              if (!json['zh-CN'][search] || !json['en-US'][search]) {
                res.send({
                  status: 500,
                  msg: 'error',
                  data: '非法key'
                })
              } else {
                json['zh-CN'][search] = zh
                json['en-US'][search] = en
              }
            }

            fs.writeFile(
              path.join(__dirname, `/branch/${branch}`, 'intl.json'),
              JSON.stringify(json, null, 2),
              'utf8',
              err => {
                if (err) {
                  res.send({
                    status: 500,
                    msg: 'error',
                    data: 'json文件写入失败'
                  })
                  return
                }
                try {
                  res.send({
                    status: 0,
                    msg: 'sucess',
                    data: json
                  })
                } catch (parseErr) {
                  console.error('Error parsing JSON:', parseErr)
                  res.send({
                    status: 500,
                    msg: 'error',
                    data: 'json解析错误'
                  })
                }
              }
            )

            fs.writeFile(
              path.join(__dirname, `/branch/${branch}`, 'zh-CN.json'),
              JSON.stringify(json['zh-CN'], null, 2),
              'utf8',
              err => {
                if (err) {
                  res.send({
                    status: 500,
                    msg: 'error',
                    data: 'json文件写入失败'
                  })
                  return
                }
                try {
                  console.log('File has been created zh-CN.json')
                } catch (parseErr) {
                  console.error('Error parsing JSON:', parseErr)
                  res.send({
                    status: 500,
                    msg: 'error',
                    data: 'json解析错误'
                  })
                }
              }
            )

            fs.writeFile(
              path.join(__dirname, `/branch/${branch}`, 'en-US.json'),
              JSON.stringify(json['en-US'], null, 2),
              'utf8',
              err => {
                if (err) {
                  res.send({
                    status: 500,
                    msg: 'error',
                    data: 'json文件写入失败'
                  })
                  return
                }

                try {
                  console.log('File has been created en-US.json')
                } catch (parseErr) {
                  console.error('Error parsing JSON:', parseErr)
                  res.send({
                    status: 500,
                    msg: 'error',
                    data: 'json解析错误'
                  })
                }
              }
            )
          } catch (err) {
            res.send({
              status: 500,
              msg: 'error',
              data: 'json文件写入失败'
            })
          }
        }
      } catch (parseErr) {
        console.error('Error parsing JSON:', parseErr)
        res.send({
          status: 500,
          msg: 'error',
          data: 'json解析错误'
        })
      }
    }
  )
})

// 创建对应分支的文件夹
// @ts-ignore
app.get('/createDir', (req: any, res) => {
  const branch = req.query.branch
  if (branch) {
    try {
      fs.mkdirSync(path.join(__dirname, `/branch/${branch}`))
      res.send({
        status: 0,
        msg: 'sucess',
        data: `目录 ${branch} 创建成功。`
      })
    } catch (err) {
      res.send({
        status: 500,
        msg: 'error',
        data: `目录 ${branch} 创建失败。`
      })
    }
  } else {
    res.send({
      status: 500,
      msg: 'error',
      data: 'branch必传'
    })
  }
})

// 脚步扫描 同步
app.post(
  '/intl/sync',
  async (
    req: {
      query: {
        branch: string
        cmpBaseUrl: string
      }
      body: any
    },
    res
  ) => {
    let json: MixJson

    const branch = req.query.branch
    const url = req.query.cmpBaseUrl || cmpBaseUrl
    const jsonDataSource = req.body

    const readFileObject = await readJsonFile(branch).catch(async err => {
      const { status } = err

      if (status === 500) {
        // 创建对应分支的文件夹
        await createDir(branch)

        // 写入文件
        await updateJsonFile(branch, jsonDataSource)

        const readFile = await readJsonFile(branch)

        res.send({
          status: readFile.status,
          msg: readFile.msg,
          data: readFile.status == 500 ? `${branch} json文件写入失败` : `${branch} json文件写入成功`
        })
      }
    })

    if (readFileObject) {
      const zhCnkeys = Object.keys(jsonDataSource['zh-CN'])
      const enUskeys = Object.keys(jsonDataSource['en-US'])

      try {
        json = JSON.parse(readFileObject?.data)

        zhCnkeys.map(key => {
          if (!json['zh-CN'][key]) {
            json['zh-CN'][key] = jsonDataSource['zh-CN'][key]
          }
        })

        enUskeys.map(key => {
          if (!json['en-US'][key]) {
            json['en-US'][key] = jsonDataSource['en-US'][key]
          }
        })

        await translate(url, json)

        await updateJsonFile(branch, json)

        res.send({
          status: 0,
          msg: 'sucess',
          data: `${branch} json文件同步成功`
        })
      } catch (parseErr) {
        console.error('Error parsing JSON:', parseErr)
        res.send({
          status: 500,
          msg: 'error',
          data: 'json解析错误'
        })
      }
    }
  }
)

function translate(cmpBaseUrl: string, json: MixJson) {
  return new Promise(async (resolve, reject) => {
    const getCmpToken = await makeRequest(
      `${cmpBaseUrl}/base/v4/pub/token/GetToken`,
      'POST',
      {
        headers: {
          'Content-Type': 'application/json'
        }
      },
      {
        username: 'admin',
        password: 'password'
      }
    )

    const token = getCmpToken.data.data.token

    const cmpConfigHeaders = {
      Authorization: `Bearer ${token}`, // 例如，添加认证令牌
      'X-Vdc-Id': '7c54bc609ffa49caa47f8d22f4d07672'
    }

    const actionInfo = await makeRequest(
      `${cmpBaseUrl}/base/v4/debug/actionInfo`,
      'GET',
      cmpConfigHeaders
    )

    const genMenusJson = await makeRequest(
      `${cmpBaseUrl}/base/v4/debug/genMenusJson?format=flat`,
      'GET',
      cmpConfigHeaders
    )

    const queryButtonGroupVoI18n = await makeRequest(
      `${cmpBaseUrl}/base/v4/debug/queryButtonGroupVoI18n`,
      'GET',
      cmpConfigHeaders
    )

    const taskKeyI18n = await makeRequest(
      `${cmpBaseUrl}/base/v4/debug/taskKeyI18n`,
      'GET',
      cmpConfigHeaders
    )

    const stepKeyI18n = await makeRequest(
      `${cmpBaseUrl}/base/v4/debug/stepKeyI18n`,
      'GET',
      cmpConfigHeaders
    )

    const renameActionInfo = lodash.mapKeys(
      actionInfo.data.data,
      (_, key) => `cmp-actionKey-${key}`
    )

    const renameTaskKeyI18n = lodash.mapKeys(
      taskKeyI18n.data.data,
      (_, key) => `cmp-taskKey-${key}`
    )

    const renameEndConfig = Object.assign(
      {},
      renameActionInfo,
      genMenusJson.data.data,
      queryButtonGroupVoI18n.data.data,
      renameTaskKeyI18n,
      stepKeyI18n.data.data
    )

    const keys = Object.keys(renameEndConfig)

    const results: Record<string, string | any> = {}

    await promiseAllLimit(
      50,
      keys.map(k => async () => {
        const str = renameEndConfig[k]
        if (str) {
          const result = await translator.translateText(str, null, 'en-US')
          // @ts-ignore
          results[k] = result.text
        } else {
          results[k] = ''
        }
      })
    )

    try {
      const actionZhValue: Record<string, string> = {}
      const actionEnValue: Record<string, string> = {}
      const menuZhValue: Record<string, string> = {}
      const menuEnValue: Record<string, string> = {}

      for (const key in actionInfo.data.data) {

        if (json['zh-CN'][key]) {

          if (!json['zh-CN'][`cmp-actionKey-${key}`]) {
            actionZhValue[`cmp-actionKey-${key}`] = json['zh-CN'][key]
            delete json['zh-CN'][key]
          } else {
            actionZhValue[`cmp-actionKey-${key}`] = json['zh-CN'][`cmp-actionKey-${key}`]
          }

        } else {
          actionZhValue[`cmp-actionKey-${key}`] = actionInfo.data.data[key]
          json['zh-CN'][key] = actionInfo.data.data[key]
        }



        if (json['en-US'][key]) {

          if (!json['en-US'][`cmp-actionKey-${key}`]) {
            actionEnValue[`cmp-actionKey-${key}`] = json['en-US'][key]
            delete json['en-US'][key]
          } else {
            actionEnValue[`cmp-actionKey-${key}`] = json['en-US'][`cmp-actionKey-${key}`]
          }

        } else {
          actionEnValue[`cmp-actionKey-${key}`] = results[key]
          json['en-US'][key] = results[key]
        }

      }

      for (const key in taskKeyI18n.data.data) {
        if (json['zh-CN'][key]) {
          if (!json['zh-CN'][`cmp-taskKey-${key}`]) {
            actionZhValue[`cmp-taskKey-${key}`] = json['zh-CN'][key]
            delete json['zh-CN'][key]
          } else {
            actionZhValue[`cmp-taskKey-${key}`] = json['zh-CN'][`cmp-taskKey-${key}`]
          }
        } else {
          actionZhValue[`cmp-taskKey-${key}`] = taskKeyI18n.data.data[key]
          json['zh-CN'][key] = taskKeyI18n.data.data[key]
        }


        if (json['en-US'][key]) {
          if (!json['en-US'][`cmp-taskKey-${key}`]) {
            actionEnValue[`cmp-taskKey-${key}`] = json['en-US'][key]
            delete json['en-US'][key]
          } else {
            actionEnValue[`cmp-taskKey-${key}`] = json['en-US'][`cmp-taskKey-${key}`]
          }
        } else {
          actionEnValue[`cmp-taskKey-${key}`] = results[key]
          json['en-US'][key] = results[key]
        }
      }

      for (const key in genMenusJson.data.data) {

        if (!json['zh-CN'][key]) {
          menuZhValue[key] = genMenusJson.data.data[key]
        } else {
          menuZhValue[key] = json['zh-CN'][key]
        }

        if (!json['en-US'][key]) {
          menuEnValue[key] = results[key]
        } else {
          menuEnValue[key] = json['en-US'][key]
        }

      }
      json['zh-CN'] = {
        ...json['zh-CN'],
        ...renameEndConfig,
        ...actionZhValue,
        ...menuZhValue
      }
      json['en-US'] = {
        ...json['en-US'],
        ...results,
        ...actionEnValue,
        ...menuEnValue
      }
      resolve(json)
    } catch (error) {
      reject(error)
    }
  })
}
// 翻译
app.get(
  '/translate',
  async (
    req: {
      query: {
        branch: string
        cmpBaseUrl: string
      }
    },
    res
  ) => {
    const branch = req.query.branch
    const url = req.query.cmpBaseUrl || cmpBaseUrl
    const getCmpToken = await makeRequest(
      `${url}/base/v4/pub/token/GetToken`,
      'POST',
      {
        headers: {
          'Content-Type': 'application/json'
        }
      },
      {
        username: 'admin',
        password: 'password'
      }
    )

    const token = getCmpToken.data.data.token

    const cmpConfigHeaders = {
      Authorization: `Bearer ${token}`, // 例如，添加认证令牌
      'X-Vdc-Id': '7c54bc609ffa49caa47f8d22f4d07672'
    }

    const actionInfo = await makeRequest(`${url}/base/v4/debug/actionInfo`, 'GET', cmpConfigHeaders)

    const genMenusJson = await makeRequest(
      `${url}/base/v4/debug/genMenusJson?format=flat`,
      'GET',
      cmpConfigHeaders
    )

    const queryButtonGroupVoI18n = await makeRequest(
      `${url}/base/v4/debug/queryButtonGroupVoI18n`,
      'GET',
      cmpConfigHeaders
    )

    const taskKeyI18n = await makeRequest(
      `${url}/base/v4/debug/taskKeyI18n`,
      'GET',
      cmpConfigHeaders
    )

    const stepKeyI18n = await makeRequest(
      `${url}/base/v4/debug/stepKeyI18n`,
      'GET',
      cmpConfigHeaders
    )

    const renameActionInfo = lodash.mapKeys(
      actionInfo.data.data,
      (_, key) => `cmp-actionKey-${key}`
    )

    const renameTaskKeyI18n = lodash.mapKeys(
      taskKeyI18n.data.data,
      (_, key) => `cmp-taskKey-${key}`
    )

    const renameEndConfig = Object.assign(
      {},
      renameActionInfo,
      genMenusJson.data.data,
      queryButtonGroupVoI18n.data.data,
      renameTaskKeyI18n,
      stepKeyI18n.data.data
    )

    const keys = Object.keys(renameEndConfig)

    const results: Record<string, string> = {}

    await promiseAllLimit(
      50,
      keys.map(k => async () => {
        const str = renameEndConfig[k]
        if (str) {
          const result = await translator.translateText(str, null, 'en-US')
          // @ts-ignore
          results[k] = result.text
        } else {
          results[k] = ''
        }
      })
    )

    fs.readFile(
      path.join(__dirname, `/branch/${branch}`, 'intl.json'),
      'utf-8',
      async (err, data) => {
        if (err) {
          res.send({
            status: 500,
            msg: 'error',
            data: 'json解析错误'
          })
          return
        }

        try {
          const json: MixJson = JSON.parse(data)

          const actionZhValue: Record<string, string> = {}
          const actionEnValue: Record<string, string> = {}
          const menuZhValue: Record<string, string> = {}
          const menuEnValue: Record<string, string> = {}

          for (const key in actionInfo.data.data) {
            if (json['zh-CN'][key]) {
              actionZhValue[`cmp-actionKey-${key}`] = json['zh-CN'][key]
              delete json['zh-CN'][key]
            }
            if (json['en-US'][key]) {
              actionEnValue[`cmp-actionKey-${key}`] = json['en-US'][key]
              delete json['en-US'][key]
            }
          }

          for (const key in taskKeyI18n.data.data) {
            if (json['zh-CN'][key]) {
              actionZhValue[`cmp-taskKey-${key}`] = json['zh-CN'][key]
              delete json['zh-CN'][key]
            }
            if (json['en-US'][key]) {
              actionEnValue[`cmp-taskKey-${key}`] = json['en-US'][key]
              delete json['en-US'][key]
            }
          }

          for (const key in genMenusJson.data.data) {
            if (json['zh-CN'][key]) {
              menuZhValue[key] = json['zh-CN'][key]
            }
            if (json['en-US'][key]) {
              menuEnValue[key] = json['en-US'][key]
            }
          }

          if (json) {
            try {
              json['zh-CN'] = {
                ...json['zh-CN'],
                ...renameEndConfig,
                ...actionZhValue,
                ...menuZhValue
              }
              json['en-US'] = {
                ...json['en-US'],
                ...results,
                ...actionEnValue,
                ...menuEnValue
              }

              await updateJsonFile(branch, json)

              res.send({
                status: 0,
                msg: 'sucess',
                data: `${branch} json文件同步成功`
              })
            } catch (err) {
              res.send({
                status: 500,
                msg: 'error',
                data: 'json文件写入失败'
              })
            }
          }
        } catch (parseErr) {
          console.error('Error parsing JSON:', parseErr)
          res.send({
            status: 500,
            msg: 'error',
            data: 'json解析错误'
          })
        }
      }
    )
  }
)

// 递归遍历JSON对象，转换英文单词的首字母为大写
function capitalizeWords(obj: any) {
  for (const key in obj) {
    if (typeof obj[key] === 'string') {
      if (obj[key].indexOf('{') > -1) {
        obj[key] = obj[key].replace(/\{[a-zA-Z]/gi, function (char: string) {
          return char.toLowerCase()
        })
      } else {
        obj[key] = obj[key].replace(/\b[a-z]/gi, function (char: string) {
          return char.toUpperCase()
        })
      }
    } else if (typeof obj[key] === 'object') {
      capitalizeWords(obj[key])
    }
  }
}
// 英文首字母大写
// @ts-ignore
app.get('/capitalizeJson', async (req, res) => {
  const branch = req.query.branch
  // @ts-ignore
  fs.readFile(path.join(__dirname, `/branch/${branch}`, 'intl.json'), 'utf-8', (err, data) => {
    if (err) {
      res.send({
        status: 500,
        msg: 'error',
        data: 'json解析错误'
      })
      return
    }

    try {
      const json = JSON.parse(data)
      if (json) {
        try {
          capitalizeWords(json)
          fs.writeFile(
            path.join(__dirname, `/branch/${branch}`, 'intl.json'),
            JSON.stringify(json, null, 2),
            'utf8',
            err => {
              if (err) {
                res.send({
                  status: 500,
                  msg: 'error',
                  data: 'json文件写入失败'
                })
                return
              }
              try {
                console.log('File has been capitalizeJson created intl.json')
                res.send({
                  status: 0,
                  msg: 'sucess',
                  data: json
                })
              } catch (parseErr) {
                console.error('Error parsing JSON:', parseErr)
                res.send({
                  status: 500,
                  msg: 'error',
                  data: 'json解析错误'
                })
              }
            }
          )

          fs.writeFile(
            path.join(__dirname, `/branch/${branch}`, 'zh-CN.json'),
            JSON.stringify(
              {
                ...json['zh-CN']
              },
              null,
              2
            ),
            'utf8',
            err => {
              if (err) {
                res.send({
                  status: 500,
                  msg: 'error',
                  data: 'json文件写入失败'
                })
                return
              }
              try {
                console.log('File has been capitalizeJson created zh-CN.json')
              } catch (parseErr) {
                console.error('Error parsing JSON:', parseErr)
                res.send({
                  status: 500,
                  msg: 'error',
                  data: 'json解析错误'
                })
              }
            }
          )

          fs.writeFile(
            path.join(__dirname, `/branch/${branch}`, 'en-US.json'),
            JSON.stringify(
              {
                ...json['en-US']
              },
              null,
              2
            ),
            'utf8',
            err => {
              if (err) {
                res.send({
                  status: 500,
                  msg: 'error',
                  data: 'json文件写入失败'
                })
                return
              }

              try {
                console.log('File has been capitalizeJson created en-US.json')
              } catch (parseErr) {
                console.error('Error parsing JSON:', parseErr)
                res.send({
                  status: 500,
                  msg: 'error',
                  data: 'json解析错误'
                })
              }
            }
          )
        } catch (err) {
          res.send({
            status: 500,
            msg: 'error',
            data: 'json文件写入失败'
          })
        }
      }
    } catch (parseErr) {
      console.error('Error parsing JSON:', parseErr)
      res.send({
        status: 500,
        msg: 'error',
        data: 'json解析错误'
      })
    }
  })
})

// 修改intl
// @ts-ignore
app.post('/intl/en/editor', async (req, res) => {
  const branch = req.query.branch
  const jsonDataSource = req.body

  fs.readFile(path.join(__dirname, `/branch/${branch}`, 'intl.json'), 'utf-8', (err, data) => {
    if (err) {
      res.send({
        status: 500,
        msg: 'error',
        data: 'json解析错误'
      })
      return
    }

    try {
      const json = JSON.parse(data)
      if (json) {
        try {
          Object.keys(jsonDataSource).forEach(key => {
            json['en-US'][key] = jsonDataSource[key]
          })
          fs.writeFile(
            path.join(__dirname, `/branch/${branch}`, 'intl.json'),
            JSON.stringify(json, null, 2),
            'utf8',
            err => {
              if (err) {
                res.send({
                  status: 500,
                  msg: 'error',
                  data: 'json文件写入失败'
                })
                return
              }
              try {
                console.log('File has been capitalizeJson created intl.json')
                res.send({
                  status: 0,
                  msg: 'sucess',
                  data: json
                })
              } catch (parseErr) {
                console.error('Error parsing JSON:', parseErr)
                res.send({
                  status: 500,
                  msg: 'error',
                  data: 'json解析错误'
                })
              }
            }
          )

          fs.writeFile(
            path.join(__dirname, `/branch/${branch}`, 'zh-CN.json'),
            JSON.stringify(
              {
                ...json['zh-CN']
              },
              null,
              2
            ),
            'utf8',
            err => {
              if (err) {
                res.send({
                  status: 500,
                  msg: 'error',
                  data: 'json文件写入失败'
                })
                return
              }
              try {
                console.log('File has been capitalizeJson created zh-CN.json')
              } catch (parseErr) {
                console.error('Error parsing JSON:', parseErr)
                res.send({
                  status: 500,
                  msg: 'error',
                  data: 'json解析错误'
                })
              }
            }
          )

          fs.writeFile(
            path.join(__dirname, `/branch/${branch}`, 'en-US.json'),
            JSON.stringify(
              {
                ...json['en-US']
              },
              null,
              2
            ),
            'utf8',
            err => {
              if (err) {
                res.send({
                  status: 500,
                  msg: 'error',
                  data: 'json文件写入失败'
                })
                return
              }

              try {
                console.log('File has been capitalizeJson created en-US.json')
              } catch (parseErr) {
                console.error('Error parsing JSON:', parseErr)
                res.send({
                  status: 500,
                  msg: 'error',
                  data: 'json解析错误'
                })
              }
            }
          )
        } catch (err) {
          res.send({
            status: 500,
            msg: 'error',
            data: 'json文件写入失败'
          })
        }
      }
    } catch (parseErr) {
      console.error('Error parsing JSON:', parseErr)
      res.send({
        status: 500,
        msg: 'error',
        data: 'json解析错误'
      })
    }
  })
})

app.listen(port, () => {
  console.log(`Mock API server is running at http://localhost:${port}`)
})
