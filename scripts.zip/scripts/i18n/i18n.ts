import { readdirSync, writeFileSync } from 'fs'
import { resolve, relative } from 'path'
import mkdirp from 'mkdirp'
import { unionBy } from 'lodash'
import type { IOnFindI18n } from './core'
import { find18nByFile } from './core'
import { getFileNamePrefixWithGit, wrapLog } from '../utils'

mkdirp(resolve(__dirname, 'log'))

const rootDir = resolve(__dirname, '../..')

const files: string[] = []

const i18nDefines: Record<string, string> = {}
let i18nList: { id: string; defaultMessage?: string; path: string }[] = []

const log: {
  duplicatedKey: { key: string; current: string; incomming?: string; codeLoc?: string }[]
  unstandard: string[]
  unconnect: { loc: string; str: string }[]
  parseError: string[]
} = {
  duplicatedKey: [],
  unconnect: [],
  unstandard: [],
  parseError: []
}

// 递归遍历文件夹并过滤
const getFiles = (dir: string) => {
  const entrys = readdirSync(dir, { withFileTypes: true })
  entrys.forEach(dirent => {
    const filePath = resolve(dir, dirent.name)
    if (/apps|components|features|utils/.test(filePath)) {
      if (/^((?!node_modules|dist\/|\.history|\.umi|locales).)*$/.test(filePath)) {
        if (dirent.isDirectory()) {
          getFiles(filePath)
        } else if (/^((?!\.d\.ts).)*(\.ts|\.tsx)$/.test(filePath)) {
          files.push(filePath)
        }
      }
    }
  })
}

const onFindI18n: IOnFindI18n = params => {
  const { id, defaultMessage, fileName, nodePath } = params

  const setI18n = (_id: string) => {
    if (i18nDefines[_id] && i18nDefines[_id] !== defaultMessage) {
      log.duplicatedKey.push({
        key: _id,
        current: i18nDefines[_id],
        incomming: defaultMessage,
        codeLoc: `${fileName}:${nodePath.node.loc?.start.line}:${nodePath.node.loc?.start.column}`
      })
    } else {
      i18nDefines[_id] = defaultMessage || ''
      if (
        !i18nList.find((item: any) => {
          return item?.id === _id
        })
      ) {
        i18nList.push({
          id: _id,
          defaultMessage,
          path: `${relative(rootDir, fileName)}#L${nodePath.node.loc?.start.line}`
        })
      }
    }
  }

  setI18n(id)
}

const build = (dir: string) => {
  const fileNamePrefix = getFileNamePrefixWithGit()
  getFiles(dir)

  writeFileSync(resolve(__dirname, 'log/file.json'), JSON.stringify(files, null, 2), {
    encoding: 'utf-8'
  })
  files.forEach(file => {
    try {
      const { unstandard = [], parseError = [], unconnect = [] } = find18nByFile(file, onFindI18n)
      log.parseError.push(...parseError)
      log.unstandard.push(...unstandard)
      log.unconnect.push(...unconnect)
    } catch (e) {
      console.error(file)
      // throw e
    }
  })
  // 字典序
  const sortResult: any = {}
  // 收集 components 下的 i18n 信息
  const componentsI18n: Record<string, string> = {}
  Object.keys(i18nDefines)
    .sort()
    .forEach(key => {
      sortResult[key] = i18nDefines[key]

      const i18n = i18nList.find(item => item && item.id === key && /^components/.test(item.path))

      if (i18n) {
        componentsI18n[key] = i18nDefines[key]
      }
    })

  writeFileSync(
    resolve(__dirname, `log/${fileNamePrefix}_i18n.json`),
    JSON.stringify(sortResult, null, 2),
    'utf-8'
  )
  writeFileSync(
    resolve(__dirname, `log/current_i18n.json`),
    JSON.stringify(sortResult, null, 2),
    'utf-8'
  )

  // 合并系统菜单
  i18nList = unionBy(i18nList, 'id')

  writeFileSync(resolve(__dirname, 'log/list.json'), JSON.stringify(i18nList, null, 2), 'utf-8')
  // writeFileSync(
  //   resolve(__dirname, '../../components/src/intl/i18n.json'),
  //   JSON.stringify(componentsI18n, null, 2),
  //   'utf-8'
  // )

  const newLog = {
    ...log,
    duplicatedKey: log.duplicatedKey.map((item, idx) => ({
      ...item,
      id: idx + 1
    }))
  }
  writeFileSync(resolve(__dirname, 'log/error.log'), JSON.stringify(newLog, null, 2), 'utf-8')

  if (log.unconnect.length) {
    wrapLog.yellow(
      `i18n 未定义: ${log.unconnect.length}，请检查 scripts/i18n/log/unconnect.log 并修改`
    )
  }
  writeFileSync(
    resolve(__dirname, 'log/unconnect.log'),
    JSON.stringify(log.unconnect, null, 2),
    'utf-8'
  )
}

build(rootDir)
