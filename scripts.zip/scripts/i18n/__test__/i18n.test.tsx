import { resolve } from 'path'
import { parse } from '@babel/parser'
import { findI18n, findI18nByObjectExpression, find18nByFile } from '../core'

describe('i18n core', () => {
  it('通过defaultMessage查找', done => {
    const code = `
      <Item
        name="username"
        validateFirst
        rules={[
          {
            required: true,
            message: intl.formatMessage({
              id: 'login.field.usename.required',
              defaultMessage: '请输入用户名'
            })
          }
        ]}
      >
        <Input
          data-testid="username"
          prefix={<Icon className={style.inputPrefixIcon} type="person-fill" />}
        />
      </Item>
    `
    const ast = parse(code, {
      sourceType: 'module',
      plugins: ['typescript', 'jsx', 'classProperties']
    })
    findI18n({
      fileName: 'test.tsx',
      ast,
      onFindI18n: ({ id, defaultMessage }) => {
        expect(id).toBe('login.field.usename.required')
        expect(defaultMessage).toBe('请输入用户名')
        done()
      }
    })
  })

  it('通过Object查找', done => {
    const code = `
      const message = {
        id: 'login.field.usename.required',
        defaultMessage: '请输入用户名'
      }
      const item = 
        <Item
          name="username"
          validateFirst
          rules={[
            {
              required: true,
              message: intl.formatMessage(message)
            }
          ]}
        >
          <Input
            data-testid="username"
            prefix={<Icon className={style.inputPrefixIcon} type="person-fill" />}
          />
        </Item>
    `
    const ast = parse(code, {
      sourceType: 'module',
      plugins: ['typescript', 'jsx', 'classProperties']
    })
    findI18nByObjectExpression({
      fileName: 'test.tsx',
      ast,
      onFindI18n: ({ id, defaultMessage }) => {
        expect(id).toBe('login.field.usename.required')
        expect(defaultMessage).toBe('请输入用户名')
        done()
      }
    })
  })

  it('通过模板字符串查找', done => {
    const code = `
      const message = {
        id: 'login.field.usename.required',
        defaultMessage: \`请输入用户名\`
      }
      const item = 
        <Item
          name="username"
          validateFirst
          rules={[
            {
              required: true,
              message: intl.formatMessage(message)
            }
          ]}
        >
          <Input
            data-testid="username"
            prefix={<Icon className={style.inputPrefixIcon} type="person-fill" />}
          />
        </Item>
    `
    const ast = parse(code, {
      sourceType: 'module',
      plugins: ['typescript', 'jsx', 'classProperties']
    })
    findI18nByObjectExpression({
      fileName: 'test.tsx',
      ast,
      onFindI18n: ({ id, defaultMessage }) => {
        expect(id).toBe('login.field.usename.required')
        expect(defaultMessage).toBe('请输入用户名')
        done()
      }
    })
  })

  it('读取文件查找', done => {
    find18nByFile(resolve(__dirname, 'demo.tsx'), ({ id, defaultMessage }) => {
      expect(id).toBe('login.field.usename.required')
      expect(defaultMessage).toBe('请输入用户名')
      done()
    })
  })
})
