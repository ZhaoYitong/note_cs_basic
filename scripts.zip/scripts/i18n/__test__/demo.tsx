/* eslint-disable */
// @ts-nocheck
const message = {
  id: 'login.field.usename.required',
  defaultMessage: '请输入用户名'
}
const item = (
  <Item
    name="username"
    validateFirst
    rules={[
      {
        required: true,
        message: intl.formatMessage(message)
      }
    ]}
  >
    <Input
      data-testid="username"
      prefix={<Icon className={style.inputPrefixIcon} type="person-fill" />}
    />
  </Item>
)
