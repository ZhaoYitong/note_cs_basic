import fs from 'fs'
import { getCurrentRemoteBranch } from '../utils'
import { DEV_I18N_MGT_NODE_IP } from '../utils/config'

// TODO: 待node端支持词条修改
const unstandardTransFilePath = 'scripts/i18n/log/unstandardTrans.json'
const main = async () => {
  const currentRemoteBranch = await getCurrentRemoteBranch()
  const newestI18n = await fetch(
    `http://${DEV_I18N_MGT_NODE_IP}/i18n/${currentRemoteBranch}/intl.json`
  )
    .then(res => {
      if (!res.ok) {
        throw new Error(`HTTP error! status: ${res.status}`)
      }
      return res.json()
    })
    .catch(error => {
      console.error('Error fetching i18n data:', error)
      throw error
    })
  const enUnstandard = newestI18n['en-US']
  const originZH = newestI18n['zh-CN']
  const keysResults: Record<string, string> = {}
  const onlyChinese: Record<string, string> = {}
  const unTrans: Record<string, string> = {}
  Object.keys(enUnstandard).forEach(key => {
    if (/[\u4e00-\u9fa5]/.test(enUnstandard[key])) {
      keysResults[key] = enUnstandard[key]
      if (/^[\u4e00-\u9fa5]+$/.test(enUnstandard[key])) {
        onlyChinese[key] = enUnstandard[key]
      }
    } else if (enUnstandard[key] === '') {
      unTrans[key] = originZH[key]
    }
  })

  const final = {
    keysResults,
    unTrans
  }

  fs.writeFileSync(unstandardTransFilePath, JSON.stringify(final, null, 2))
}

main()
