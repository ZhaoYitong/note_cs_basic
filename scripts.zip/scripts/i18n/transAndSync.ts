import * as deepl from 'deepl-node'
import fs from 'fs'
import { promiseAllLimit } from './utils'
import { getCurrentRemoteBranch, getDevIp } from '../utils'
import { DEFAULT_DEV_IP as i18nMgtNode, DEV_I18N_MGT_NODE_IP } from '../utils/config'

// 当前中文词条集
const currentI18nZhFilePath = 'apps/base/src/locales/zh-CN.json'
const currentI18nEnFilePath = 'apps/base/src/locales/en-US.json'
const currentScannedI18nFilePath = 'scripts/i18n/log/current_i18n.json'
const newI18nKeyJsonPath = 'scripts/i18n/log/newI18nKey.json'
const authKey = 'eb227fbc-b27a-4ebf-8362-47764fbc1395:fx' // Replace with your key

const translator = new deepl.Translator(authKey)

const getBranchExistStatusInNodeMgt = async (
  branch: string
): Promise<{
  valid: boolean
  exist: boolean
}> => {
  if (branch) {
    try {
      await fetch(`http://${DEV_I18N_MGT_NODE_IP}/i18n/${branch}/zh-CN.json`)
      return {
        valid: true,
        exist: true
      }
    } catch (e) {
      // 报错就是无分支
      return {
        valid: true,
        exist: false
      }
    }
  } else {
    return {
      valid: false,
      exist: false
    }
  }
}

const main = async () => {
  // 手动配置分支
  // ts-node scripts/i18n/transAndSync.ts 4.0.0-dev
  const currentBranch = (await getCurrentRemoteBranch()) || process.argv[2]
  console.log('Current git branch:', currentBranch)

  const originZhJson = JSON.parse(fs.readFileSync(currentI18nZhFilePath, 'utf-8'))
  const originEnJson = JSON.parse(fs.readFileSync(currentI18nEnFilePath, 'utf-8'))
  const branchExistStatus = await getBranchExistStatusInNodeMgt(currentBranch)

  if (branchExistStatus.valid) {
    const syncResults = {
      'zh-CN': originZhJson,
      'en-US': originEnJson
    }
    if (branchExistStatus.exist) {
      const currentScannedI18nJson = JSON.parse(
        fs.readFileSync(currentScannedI18nFilePath, 'utf-8')
      )
      const enResults: Record<string, string> = {}
      const newKeysToTrans: Record<string, string> = {}
      Object.keys(currentScannedI18nJson).forEach(k => {
        // @ts-ignore
        if (!originZhJson[k]) {
          console.log(`发现新增 i18n 词条：${k}`)
          // @ts-ignore
          newKeysToTrans[k] = currentScannedI18nJson[k]
        }
      })
      console.log(
        `当前新增 i18n 词条共有 ${
          Object.keys(newKeysToTrans).length
        } 条，详情请参考文件 scripts/i18n/log/newI18n.json`
      )
      fs.writeFileSync(newI18nKeyJsonPath, JSON.stringify(newKeysToTrans, null, 2))
      const keys = Object.keys(newKeysToTrans)
      await promiseAllLimit(
        30,
        keys.map(k => async () => {
          // @ts-ignore
          const str = newKeysToTrans[k]
          if (str) {
            const result = await translator.translateText(str, null, 'en-US')
            let resTxt: string = result.text
            if (resTxt.charCodeAt(0) >= 97 && resTxt.charCodeAt(0) <= 122) {
              resTxt = resTxt.charAt(0).toUpperCase() + resTxt.slice(1)
            }
            // @ts-ignore
            enResults[k] = resTxt
            // @ts-ignore
            console.log(resTxt)
          } else {
            enResults[k] = ''
          }
        })
      )

      syncResults['zh-CN'] = newKeysToTrans
      syncResults['en-US'] = enResults
    }

    const currentRealDevIp = getDevIp()
    console.log(JSON.stringify(syncResults))

    await fetch(
      `http://${i18nMgtNode}:8004/intl/sync?branch=${currentBranch}&cmpBaseUrl=http://${currentRealDevIp}:8100`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(syncResults)
      }
    )
  } else {
    console.error(`Dev ${i18nMgtNode} response error`)
  }
}

main()
