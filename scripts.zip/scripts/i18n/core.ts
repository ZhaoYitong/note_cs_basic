import { readFileSync } from 'fs'
import { uniqBy } from 'lodash'
import { parse } from '@babel/parser'
import type { NodePath } from '@babel/traverse'
import traverse from '@babel/traverse'
import type * as t from '@babel/types'

interface onFindI18nParam {
  id: string
  nodePath: NodePath<t.Node>
  idNode: t.Property
  fileName: string
  messageNode?: t.Property
  defaultMessage?: string
}
export type IOnFindI18n = (params: onFindI18nParam) => void

export interface IFindI18nParam {
  ast: t.File
  fileName: string
  onFindI18n?: IOnFindI18n
}

export interface IFindResult {
  unstandard: string[]
  unconnect: {
    loc: string
    str: string
  }[]
  parseError: string[]
  parseByObjectExpression: { ast: t.File; fileName: string }[]
}

const getNodeValue = (node: t.ObjectProperty) => {
  // 处理字符串模板和普通字符串
  return node?.value?.type === 'TemplateLiteral'
    ? node?.value.quasis[0].value.cooked
    : (node?.value as t.StringLiteral)?.value
}

export const findI18n = (params: IFindI18nParam) => {
  const { ast, fileName, onFindI18n } = params
  const result: IFindResult = {
    unstandard: [],
    unconnect: [],
    parseError: [],
    parseByObjectExpression: []
  }
  traverse(ast, {
    enter(nodePath) {
      // 检查当前节点是否有 @ignore-i18n，如果有，则跳过
      const isCurrentFileIgnoreI18n = nodePath.node.leadingComments?.some(
        it => it.value.trim() === '@ignore-i18n'
      )
      if (isCurrentFileIgnoreI18n) {
        nodePath.skip()
      }

      // 找未关联 formatMessage 的中文字符串
      const node = nodePath.node
      if (node.type === 'StringLiteral') {
        const value = node.value
        // 检查字符串是否包含中文字符
        const regex = /[\u4e00-\u9fa5]/
        // @ts-ignore
        const isDefaultMessage = nodePath.parentPath?.node?.key?.name === 'defaultMessage'
        if (regex.test(value) && !isDefaultMessage) {
          const parentNode = nodePath.parentPath?.node
          result.unconnect.push({
            loc: `${fileName}:${parentNode?.loc?.start.line}:${parentNode?.loc?.start.column}`,
            str: value
          })
        }
      }
      // 找到 formatMessage 方法
      if (nodePath.isIdentifier({ name: 'formatMessage' })) {
        // 找到参数
        const parent = nodePath.findParent(
          it => it.isCallExpression() || it.isOptionalCallExpression()
        ) as NodePath<t.CallExpression | t.OptionalCallExpression>
        if (!parent) {
          result.unstandard.push(
            `${fileName}:${nodePath.node.loc?.start.line}:${nodePath.node.loc?.start.column}`
          )
          return
        }
        try {
          const { properties } = (parent.node.arguments[0] as t.ObjectExpression) || {}
          if (!properties) {
            result.unstandard.push(
              `${fileName}:${parent.node.loc?.start.line}:${parent.node.loc?.start.column}`
            )
            // 通过formatMessage参数模式找不到的再通过Object模式去找
            result.parseByObjectExpression.push({ ast, fileName })
            return
          }
          const idNode = properties.find((prop: any) => prop.key.name === 'id') as t.ObjectProperty
          const messageNode = properties.find(
            (prop: any) => prop.key.name === 'defaultMessage'
          ) as t.ObjectProperty
          if (!messageNode) {
            result.unstandard.push(
              `${fileName}:${idNode.loc?.start.line}:${idNode.loc?.start.column}`
            )
          }
          if (idNode) {
            // 处理字符串模板和普通字符串
            const id = getNodeValue(idNode)
            if (!id) {
              result.unstandard.push(
                `${fileName}:${parent.node.loc?.start.line}:${parent.node.loc?.start.column}`
              )
              return
            }
            const defaultMessage = getNodeValue(messageNode)
            if (!defaultMessage) {
              result.unstandard.push(
                `${fileName}:${parent.node.loc?.start.line}:${parent.node.loc?.start.column}`
              )
            }
            if (onFindI18n) {
              onFindI18n({
                id,
                idNode,
                fileName,
                nodePath,
                messageNode,
                defaultMessage
              })
            }
          }
        } catch (e) {
          result.parseError.push(`something wrong in ${fileName} ${e}`)
          result.parseByObjectExpression.push({ ast, fileName })
        }
      }
    }
  })
  return result
}

// 通过{id, defaultMessage}来找定义
export const findI18nByObjectExpression = (params: IFindI18nParam) => {
  const { ast, fileName, onFindI18n } = params
  traverse(ast, {
    enter(nodePath) {
      if (nodePath.isIdentifier({ name: 'defaultMessage' })) {
        const parent = nodePath.findParent(it =>
          it.isObjectExpression()
        ) as NodePath<t.ObjectExpression>
        if (!parent) return
        const { properties } = parent.node
        const idNode = properties.find((prop: any) => prop.key.name === 'id') as t.ObjectProperty
        const messageNode = properties.find(
          (prop: any) => prop.key.name === 'defaultMessage'
        ) as t.ObjectProperty
        if (idNode && messageNode) {
          const id = getNodeValue(idNode)
          const defaultMessage = getNodeValue(messageNode)
          if (!id) return
          if (onFindI18n) {
            onFindI18n({
              id: id,
              idNode,
              fileName,
              nodePath,
              messageNode,
              defaultMessage
            })
          }
        }
      }
    }
  })
}

export const find18nByFile = (fileName: string, onFindI18n: IOnFindI18n) => {
  const code = readFileSync(fileName, { encoding: 'utf-8' })
  const ast = parse(code, {
    sourceType: 'module',
    plugins: ['typescript', 'jsx', 'classProperties', 'decorators-legacy']
  })
  const { parseByObjectExpression = [], ...rest } = findI18n({ ast, fileName, onFindI18n })
  uniqBy(parseByObjectExpression, 'fileName').forEach(cv =>
    findI18nByObjectExpression({ ...cv, onFindI18n })
  )
  return { ast, code, ...rest }
}
