export const ACTION_CONFIG_FILE_PATH = 'features/src/actionKey/config.ts'

export type ActionData = Record<string, string[]>
