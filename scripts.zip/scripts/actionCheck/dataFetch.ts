import { getCookieByLogin } from '../utils'

export const fetchKeysByIp = async (
  devIp: string
): Promise<Record<string, string[]>> => {
  const { token } = await getCookieByLogin(devIp)
  const url = `http://${devIp}:8100/base/v4/debug/actionRouteInfo`
  const res: any = await fetch(url, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
      'X-Vdc-Id': '7c54bc609ffa49caa47f8d22f4d07672'
    }
  }).then(resp => resp.json())
  return res.data
}
