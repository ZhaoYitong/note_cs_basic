const _ = require('lodash')
const shell = require('shelljs')
const path = require('path')
const chalk = require('chalk')
const yParser = require('yargs-parser')
const fs = require('fs-extra')
const readline = require('readline')
const os = require('os')
const config = require('./config')

const { base, subApps } = config
let apps = [base].concat(subApps)

const cwd = process.cwd()
const log = console.log
const argv = yParser(process.argv.slice(2))

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  terminal: false
})

const _chalk = {
  grey: msg => chalk.hex('#e8e8e8')(msg),
  green: msg => chalk.hex('#73d13d')(msg),
  yellow: msg => chalk.hex('#fff566')(msg),
  red: msg => chalk.hex('#ff7875')(msg)
}

if (argv.help) {
  console.log('--help')
  console.log('--skip', _chalk.green('skip build libs'))
  console.log('--list', _chalk.green('list all apps'))
  console.log('--sourcemap', _chalk.green('build with sourcemap'))
  console.log('--apps', _chalk.green('build all'))
  console.log('--apps base,dashboard', _chalk.green('build base,dashboard'))
  console.log('--zstackoem', _chalk.green('NO OEM'))
  console.log('--zstackoem CTStack', _chalk.green('OEM is CTStack'))
  console.log('--hcsooem', _chalk.green('NO OEM'))
  console.log('--hcsooem 安徽电信政务云', _chalk.green('OEM is 安徽电信政务云'))
  console.log('--sso', _chalk.green('login by sso'))
  console.log('--commit 9fbf8d6d4', _chalk.green('last commit id is 9fbf8d6d4'))
  process.exit()
}

if (argv.list) {
  console.log(apps)
  process.exit()
}

if (argv.sourcemap) {
  process.env.SOURCE_MAP = true
}

if (argv.zstackoem) {
  process.env.__ZSTACKOEM__ = argv.zstackoem
} else {
  process.env.__ZSTACKOEM__ = 'ZStack Cloud'
}

if (argv.sso) {
  process.env.__SSO__ = true
}

if (argv.exchangeLanguage) {
  process.env.__EXCHANGELANGUAGE__ = true
}

if (argv.buildId) {
  process.env.__BUILDID__ = argv.buildId
}

if (argv.branchName) {
  process.env.__BRANCHNAME__ = argv.branchName
}

const buildLibs = async () => {
  if (argv.skip) {
    return
  }
  shell.cd(cwd)
  const process = shell.exec('yarn build:libs', {
    async: true
  })
  return new Promise((resolve, reject) => {
    process.on('exit', () => {
      log(_chalk.green('build: libs success'))
      resolve()
    })
    process.on('unhandledRejection', err => {
      log(_chalk.red(err))
      reject(err)
    })
  })
}

const buildFunc = app => {
  const appName = app.split('/').slice(1).join('/')
  log(chalk.yellow('build:', appName))
  let appPath = path.resolve(app)
  if (app === base) {
    shell.cd(path.resolve(cwd))
    shell.exec('rm -f dist/*')
    shell.exec('rm -rf dist/static')
  }
  shell.cd(appPath)
  log(appPath)
  // 异步编译
  let process = shell.exec('yarn build', {
    async: true
  })
  return new Promise((resolve, reject) => {
    process.on('exit', () => {
      console.log(_chalk.green(`build: ${appName} success`))
      let distPath = path.resolve(cwd, `dist/${appName}`)
      // base特殊处理
      if (appName === 'base') {
        distPath = path.resolve(cwd, 'dist')
        fs.ensureDirSync(distPath)
      } else {
        fs.emptyDirSync(distPath)
      }
      shell.cp('-rf', path.resolve(appPath, 'dist/*'), distPath)
      resolve()
    })
    process.on('error', () => {
      console.log(_chalk.red(`build: ${appName} fail`))
      reject()
    })
  })
}

const build = async apps => {
  try {
    console.time('libs build')
    await buildLibs()
    console.timeEnd('libs build')

    console.time('apps build')
    process.env.APPS = apps.map(app => {
      const appNameArr = app.split('/')
      if (appNameArr[0] === 'apps') {
        appNameArr.shift()
      }
      return appNameArr.join('/')
    })

    for (const currentBuildApps of _.chunk(apps, os.cpus().length)) {
      const promiseArray = currentBuildApps.map(app => {
        const promise = buildFunc(app)
        shell.cd(path.resolve(cwd))
        return promise
      })
      await Promise.all(promiseArray)
    }

    console.timeEnd('apps build')
    log(_chalk.green('build success!'))
    process.exit()
  } catch (err) {
    log(_chalk.red(err))
    process.exit(-1)
  }
}

if (!argv.apps) {
  log('App列表 \n')

  log('名称'.padEnd(28, ' '), '编号')
  apps.forEach((app, index) => {
    log(app.split('/').pop().padEnd(30, ' '), _chalk.yellow(index + 1))
  })

  log('\n请输入App编号，以英文逗号分隔 \n')

  rl.on('line', line => {
    const appCodes = line.split(',')
    apps = apps.filter((app, index) => {
      return appCodes.indexOf((index + 1).toString()) >= 0
    })
    build(apps)
  })
} else if (typeof argv.apps === 'string') {
  apps = argv.apps.split(',')
  build(apps)
} else {
  build(apps)
}
