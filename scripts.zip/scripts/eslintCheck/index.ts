import { execSync } from 'child_process'
import fs from 'fs'

// 指定要执行 ESLint 的文件夹
const eslintDirs = ['features', 'scripts', 'components', 'apps', 'utils']
const omitDirs = ['node_modules', '.umi', '.umi-production', 'dist']

// 遍历文件夹列表
for (const dir of eslintDirs) {
  // 对于 "apps" 文件夹，获取所有子文件夹并执行 ESLint
  if (!omitDirs.includes(dir)) {
    if (dir === 'apps') {
      const appDirs = fs
        .readdirSync(dir, { withFileTypes: true })
        .filter(dirent => dirent.isDirectory())
        .map(dirent => dirent.name)

      for (const appDir of appDirs) {
        const command = `yarn run eslint ${dir}/${appDir} --ext .ts,.tsx --quiet --fix`
        console.log(`eslinting ${dir}/${appDir}`)
        try {
          execSync(command, { stdio: 'inherit' })
        } catch (error: any) {
          console.error(`Error running ESLint in ${dir}/${appDir}:`, error.message)
          process.exit(1)
        }
      }
    } else {
      // 对于其他文件夹，直接执行 ESLint
      const command = `yarn run eslint ${dir} --ext .ts,.tsx --quiet --fix`
      console.log(`eslinting ${dir}`)
      try {
        execSync(command, { stdio: 'inherit' })
      } catch (error: any) {
        console.error(`Error running ESLint in ${dir}:`, error.message)
        process.exit(1)
      }
    }
  }
}
